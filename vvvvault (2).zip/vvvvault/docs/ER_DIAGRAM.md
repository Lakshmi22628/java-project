# VaultX ER Diagram

```mermaid
erDiagram
    USERS ||--o{ DOCUMENTS : owns
    USERS ||--o{ AUDIT_LOGS : performs
    USERS ||--o{ OTP_VERIFICATION : receives
    USERS ||--o{ SHARED_DOCUMENTS : shares
    USERS ||--o{ RECYCLE_BIN : deletes
    DOCUMENTS ||--|| DOCUMENT_DATA : stores
    DOCUMENTS ||--o{ DOCUMENT_VERSIONS : versions
    DOCUMENTS ||--o{ SHARED_DOCUMENTS : shared
    DOCUMENTS ||--o| DIGITAL_SIGNATURE : signed
    DOCUMENTS ||--o| RECYCLE_BIN : recycled
```
