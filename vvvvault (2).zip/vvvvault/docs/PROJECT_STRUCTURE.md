# VaultX Project Structure

```text
src/
  main/
    java/com/vaultx/
      config/
      controller/
      dto/
      entity/
      enums/
      repository/
      security/
      service/
      service/impl/
      util/
    resources/
      static/css
      static/js
      templates/
        admin/
        auth/
        document/
        fragments/
      application.properties
      schema.sql
```
