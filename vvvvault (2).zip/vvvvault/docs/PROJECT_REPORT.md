# VaultX Project Report

## 1. Project Title
VaultX - Secure Digital Document Vault

## 2. Abstract
VaultX is a secure web application for storing, searching, sharing, versioning, and recovering digital documents. It is built with Spring Boot, Spring Security, Thymeleaf, JPA/Hibernate, MySQL, and Apache PDFBox. The application focuses on privacy and controlled document access by combining encrypted file storage, OTP-based verification, role-based access control, audit logging, QR-based sharing, and document lifecycle management.

## 3. Problem Statement
Many users keep important files in unsecured folders, cloud drives, or chat attachments without encryption or access control. This creates risks such as unauthorized access, accidental deletion, lack of traceability, and poor document organization. VaultX addresses these issues by providing a centralized vault with encryption, authentication, version history, recycle bin recovery, and secure sharing.

## 4. Objectives
- Provide a secure place to upload and store documents.
- Protect file contents using AES-GCM encryption.
- Verify users through login and OTP-based email flows.
- Allow document search, categorization, sharing, and recovery.
- Keep an audit trail of important actions.
- Support PDF tools such as merge and image-to-PDF conversion.

## 5. Technology Stack
- Backend: Spring Boot
- Security: Spring Security, BCrypt, OTP verification
- Persistence: Spring Data JPA, Hibernate
- Database: MySQL
- Frontend: Thymeleaf, Bootstrap, HTML, CSS, JavaScript
- File Processing: Apache PDFBox
- Encryption: AES-GCM
- Utilities: QR code generation, hashing, Java Mail

## 6. Core Modules
### 6.1 Authentication Module
Handles user registration, login, logout, OTP verification, forgot password, and password reset.

### 6.2 Document Module
Supports document upload, download, preview, view, edit metadata, version upload, deletion, restore, and public sharing.

### 6.3 Search Module
Extracts searchable text from PDFs and allows keyword-based search across stored documents.

### 6.4 Security Module
Implements password hashing, encrypted storage, access control, and signature/hash verification.

### 6.5 Admin Module
Provides analytics, user overview, document statistics, audit logs, and storage reporting.

### 6.6 PDF Tools Module
Supports PDF merge and image-to-PDF conversion.

## 7. System Architecture
VaultX follows a layered MVC architecture:

- Controller layer handles HTTP requests and responses.
- Service layer contains business logic.
- Repository layer interacts with the database.
- Entity layer maps the persistent data model.
- Utility layer handles encryption, PDF processing, hashing, and QR code creation.

## 8. Database Design
The database stores:
- Users
- Documents
- Encrypted document data
- Document versions
- Shared document permissions
- OTP verification records
- Recycle bin records
- Digital signatures
- Audit logs
- Storage reports

Key relationships include:
- One user can own many documents.
- One document can have multiple versions.
- One document can be shared with multiple users.
- One document can be moved to the recycle bin.
- One document can store encrypted content separately from metadata.

## 9. Main Features
- Secure registration and login
- OTP-based email verification and password reset
- AES-encrypted document storage
- Search inside PDF content
- Category-based document organization
- Upload new document versions
- Share documents with view or download permissions
- Recycle bin and restore support
- QR code public download links
- Audit logging for critical actions
- Admin dashboard and storage reports
- PDF merge and image-to-PDF conversion

## 10. User Flow
1. A user registers and verifies the account with OTP.
2. The user logs in securely.
3. The user uploads documents with title, category, and optional signer information.
4. The system encrypts and stores file content in MySQL.
5. The user can search, preview, download, share, edit, version, or delete documents.
6. Deleted documents go to the recycle bin and can be restored.
7. Admin users can monitor usage and audit activity.

## 11. Security Approach
- Passwords are hashed with BCrypt.
- File content is encrypted before database storage.
- Downloads are decrypted only after access checks.
- OTP is used for verification and password reset.
- Sensitive configuration values are externalized through environment variables.
- Audit logs record major actions.

## 12. Deployment Notes
VaultX can be run locally with Maven or deployed to cloud platforms using environment variables. The application is designed to work with a public base URL, externalized secrets, and a reachable MySQL database. For production, the recommended setup is to keep the app and database in the same hosting ecosystem or use a MySQL provider with a public JDBC endpoint.

## 13. Testing and Verification
The project has been validated through:
- Successful local compilation
- Secure login and registration flows
- Document upload and retrieval
- PDF merge and image conversion flows
- Deployment troubleshooting and runtime log verification

## 14. Future Scope
- Add PDF to DOCX and DOCX to PDF conversion
- Add document tagging and advanced filters
- Introduce full-text indexing for faster search
- Add email-based document sharing links with expiry
- Support cloud object storage for large files
- Add two-factor authentication with authenticator apps

## 15. Conclusion
VaultX demonstrates a practical secure vault solution for personal and organizational document management. It combines encryption, authentication, searchable documents, sharing, version control, and admin monitoring into a single Spring Boot application. The system is suitable as a final-year project or a secure document management prototype.
