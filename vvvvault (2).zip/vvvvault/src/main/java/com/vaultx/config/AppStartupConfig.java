package com.vaultx.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.vaultx.entity.User;
import com.vaultx.enums.Role;
import com.vaultx.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Configuration
@RequiredArgsConstructor
public class AppStartupConfig {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Bean
    CommandLineRunner seedAdminUser() {
        return args -> {
            if (userRepository.existsByEmail("vaultx89@gmail.com")) {
                return;
            }
            User admin = new User();
            admin.setFullName("VaultX Administrator");
            admin.setEmail("vaultx89@gmail.com");
            admin.setPassword(passwordEncoder.encode("Admin@123"));
            admin.setRole(Role.ROLE_ADMIN);
            admin.setEmailVerified(true);
            admin.setTwoFactorEnabled(true);
            userRepository.save(admin);
        };
    }

    @Bean
    CommandLineRunner cleanupLegacyDocumentUserColumn(JdbcTemplate jdbcTemplate) {
        return args -> {
            Integer userIdColumn = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'documents' AND COLUMN_NAME = 'user_id'",
                    Integer.class);
            Integer ownerIdColumn = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'documents' AND COLUMN_NAME = 'owner_id'",
                    Integer.class);

            if (userIdColumn != null && userIdColumn > 0) {
                if (ownerIdColumn != null && ownerIdColumn > 0) {
                    jdbcTemplate.execute("ALTER TABLE documents DROP COLUMN user_id");
                } else {
                    jdbcTemplate.execute("ALTER TABLE documents CHANGE COLUMN user_id owner_id BIGINT NOT NULL");
                }
            }
        };
    }
}
