package com.vaultx.config;

import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.util.Collections;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.web.context.WebServerApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@RequiredArgsConstructor
public class AccessUrlLogger {

    private static final Logger log = LoggerFactory.getLogger(AccessUrlLogger.class);

    private final WebServerApplicationContext webServerApplicationContext;

    @Bean
    ApplicationRunner logAccessUrls() {
        return args -> {
            int port = webServerApplicationContext.getWebServer().getPort();
            String baseUrl = "http://localhost:" + port;
            log.info("VaultX started successfully.");
            log.info("Local access: http://localhost:{}", port);
            log.info("Configured base URL: {}", baseUrl);
            for (NetworkInterface networkInterface : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!networkInterface.isUp() || networkInterface.isLoopback() || networkInterface.isVirtual()) {
                    continue;
                }
                for (var address : Collections.list(networkInterface.getInetAddresses())) {
                    if (address instanceof Inet4Address inet4Address && !inet4Address.isLoopbackAddress()) {
                        log.info("LAN access: http://{}:{}", inet4Address.getHostAddress(), port);
                    }
                }
            }
        };
    }
}
