package com.vaultx.enums;

public enum SharePermission {
    VIEW,
    DOWNLOAD
}
