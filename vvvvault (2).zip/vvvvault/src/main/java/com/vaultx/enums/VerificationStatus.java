package com.vaultx.enums;

public enum VerificationStatus {
    VERIFIED,
    FAILED,
    PENDING
}
