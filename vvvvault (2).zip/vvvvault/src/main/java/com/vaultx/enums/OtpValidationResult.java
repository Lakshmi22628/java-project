package com.vaultx.enums;

public enum OtpValidationResult {
    VALID,
    INVALID,
    EXPIRED,
    NOT_FOUND
}
