package com.vaultx.enums;

public enum DocumentCategory {
    AADHAR,
    PAN,
    MARKS_CARD,
    CERTIFICATE,
    PASSPORT,
    LICENSE,
    INSURANCE,
    BANK,
    NOTES,
    BILLS,
    TAX,
    MEDICAL,
    PROPERTY,
    EDUCATION,
    WORK,
    RECEIPT,
    OTHER
}
