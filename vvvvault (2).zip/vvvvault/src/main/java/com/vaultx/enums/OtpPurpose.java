package com.vaultx.enums;

public enum OtpPurpose {
    LOGIN,
    TWO_FACTOR,
    PASSWORD_RESET
}
