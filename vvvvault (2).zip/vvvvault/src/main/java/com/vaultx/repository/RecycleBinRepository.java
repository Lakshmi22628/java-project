package com.vaultx.repository;

import com.vaultx.entity.RecycleBin;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecycleBinRepository extends JpaRepository<RecycleBin, Long> {

    List<RecycleBin> findByDeletedByIdOrderByDeletedAtDesc(Long userId);

    Optional<RecycleBin> findByDocumentId(Long documentId);

    void deleteByDocumentId(Long documentId);

    List<RecycleBin> findByRestoreDeadlineBefore(LocalDateTime time);
}
