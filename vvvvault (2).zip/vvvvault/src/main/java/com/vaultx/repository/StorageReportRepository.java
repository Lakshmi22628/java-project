package com.vaultx.repository;

import com.vaultx.entity.StorageReport;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StorageReportRepository extends JpaRepository<StorageReport, Long> {

    List<StorageReport> findTop7ByOrderByReportDateDesc();
}
