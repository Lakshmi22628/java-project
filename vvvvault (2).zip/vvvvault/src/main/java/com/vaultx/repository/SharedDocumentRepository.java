package com.vaultx.repository;

import com.vaultx.entity.SharedDocument;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SharedDocumentRepository extends JpaRepository<SharedDocument, Long> {

    List<SharedDocument> findBySharedWithUserIdOrderBySharedAtDesc(Long userId);

    List<SharedDocument> findByOwnerIdOrderBySharedAtDesc(Long ownerId);

    Optional<SharedDocument> findByDocumentIdAndSharedWithUserId(Long documentId, Long userId);
}
