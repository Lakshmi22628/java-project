package com.vaultx.repository;

import com.vaultx.entity.OtpVerification;
import com.vaultx.entity.User;
import com.vaultx.enums.OtpPurpose;
import java.time.LocalDateTime;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface OtpVerificationRepository extends JpaRepository<OtpVerification, Long> {

    Optional<OtpVerification> findTopByUserAndPurposeAndUsedFalseOrderByCreatedAtDesc(User user, OtpPurpose purpose);

    @Modifying
    @Query("delete from OtpVerification o where o.expiresAt < :time")
    void deleteExpiredOtps(@Param("time") LocalDateTime time);

    @Modifying
    @Query("update OtpVerification o set o.used = true where o.user = :user and o.purpose = :purpose and o.used = false")
    void invalidateActiveOtps(@Param("user") User user, @Param("purpose") OtpPurpose purpose);
}
