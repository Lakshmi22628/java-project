package com.vaultx.repository;

import com.vaultx.entity.Document;
import com.vaultx.entity.User;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DocumentRepository extends JpaRepository<Document, Long> {

    List<Document> findByOwnerAndDeletedFalseOrderByUpdatedAtDesc(User owner);

    List<Document> findByDeletedTrueOrderByUpdatedAtDesc();

    List<Document> findByOwnerAndDeletedTrueOrderByUpdatedAtDesc(User owner);

    List<Document> findByDeletedFalseOrderByUpdatedAtDesc();

    List<Document> findByExtractedTextContainingIgnoreCaseAndDeletedFalse(String keyword);

    Optional<Document> findByQrTokenAndDeletedFalse(String qrToken);

    Page<Document> findAllByOrderByCreatedAtDesc(Pageable pageable);

    Page<Document> findByContentTypeIgnoreCaseOrderByCreatedAtDesc(String contentType, Pageable pageable);

    Page<Document> findByOwner_EmailContainingIgnoreCaseOrderByCreatedAtDesc(String userEmail, Pageable pageable);

    Page<Document> findByContentTypeIgnoreCaseAndOwner_EmailContainingIgnoreCaseOrderByCreatedAtDesc(String contentType, String userEmail, Pageable pageable);
}
