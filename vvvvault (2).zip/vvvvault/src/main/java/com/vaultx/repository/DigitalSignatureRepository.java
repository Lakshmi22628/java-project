package com.vaultx.repository;

import com.vaultx.entity.DigitalSignature;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DigitalSignatureRepository extends JpaRepository<DigitalSignature, Long> {

    Optional<DigitalSignature> findByDocumentId(Long documentId);

    void deleteByDocumentId(Long documentId);
}
