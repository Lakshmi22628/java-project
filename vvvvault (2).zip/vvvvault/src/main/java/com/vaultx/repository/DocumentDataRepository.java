package com.vaultx.repository;

import com.vaultx.entity.DocumentData;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DocumentDataRepository extends JpaRepository<DocumentData, Long> {

    Optional<DocumentData> findByDocumentId(Long documentId);
}
