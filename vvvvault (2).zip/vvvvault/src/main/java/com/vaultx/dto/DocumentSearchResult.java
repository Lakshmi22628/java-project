package com.vaultx.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class DocumentSearchResult {
    private Long documentId;
    private String title;
    private String category;
    private String snippet;
}
