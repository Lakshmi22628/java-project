package com.vaultx.dto;

import com.vaultx.entity.Document;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DocumentCategoryFolder {

    private String folderKey;
    private String folderName;
    private String filterValue;
    private String iconLabel;
    private String accentClass;
    private List<Document> documents;
}
