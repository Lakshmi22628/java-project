package com.vaultx.dto;

import com.vaultx.enums.DocumentCategory;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DocumentUploadRequest {

    private String title;
    private DocumentCategory category;
    private String customCategory;
    private String signerName;
}
