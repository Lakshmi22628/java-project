package com.vaultx.dto;

import com.vaultx.enums.SharePermission;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ShareDocumentRequest {

    @Email
    @NotBlank
    private String recipientEmail;

    private SharePermission permission = SharePermission.VIEW;
}
