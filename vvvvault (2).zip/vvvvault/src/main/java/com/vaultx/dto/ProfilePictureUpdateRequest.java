package com.vaultx.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProfilePictureUpdateRequest {

    private String profilePictureData;
    private String profilePictureContentType;
}
