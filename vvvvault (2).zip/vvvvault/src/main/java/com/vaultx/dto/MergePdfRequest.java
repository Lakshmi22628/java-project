package com.vaultx.dto;

import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MergePdfRequest {

    private List<Long> documentIds = new ArrayList<>();
    private String title;
    private String signerName;
}
