package com.vaultx.dto;

import com.vaultx.enums.DocumentCategory;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DocumentUpdateRequest {

    private String title;
    private String originalFileName;
    private DocumentCategory category;
    private String customCategory;
}
