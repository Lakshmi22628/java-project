package com.vaultx.service.impl;

import com.vaultx.entity.AuditLog;
import com.vaultx.entity.Document;
import com.vaultx.entity.StorageReport;
import com.vaultx.entity.User;
import com.vaultx.enums.Role;
import com.vaultx.repository.AuditLogRepository;
import com.vaultx.repository.DigitalSignatureRepository;
import com.vaultx.repository.DocumentRepository;
import com.vaultx.repository.RecycleBinRepository;
import com.vaultx.repository.StorageReportRepository;
import com.vaultx.repository.UserRepository;
import com.vaultx.service.AdminService;
import java.util.Objects;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {

    private final UserRepository userRepository;
    private final DocumentRepository documentRepository;
    private final DigitalSignatureRepository digitalSignatureRepository;
    private final RecycleBinRepository recycleBinRepository;
    private final StorageReportRepository storageReportRepository;
    private final AuditLogRepository auditLogRepository;

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public List<Document> getAllDocuments() {
        return documentRepository.findAll(Sort.by(Sort.Order.desc("createdAt")));
    }

    @Override
    public List<StorageReport> getStorageReports() {
        refreshStorageReport();
        return storageReportRepository.findTop7ByOrderByReportDateDesc()
                .stream()
                .sorted((a, b) -> a.getReportDate().compareTo(b.getReportDate()))
                .toList();
    }

    @Override
    public void refreshStorageReport() {
        boolean exists = storageReportRepository.findTop7ByOrderByReportDateDesc()
                .stream()
                .anyMatch(report -> report.getReportDate().equals(LocalDate.now()));
        if (exists) {
            return;
        }
        StorageReport report = new StorageReport();
        report.setReportDate(LocalDate.now());
        report.setTotalDocuments((long) documentRepository.findAll().size());
        report.setTotalSizeBytes(documentRepository.findAll().stream().mapToLong(Document::getSizeInBytes).sum());
        report.setActiveUsers((long) userRepository.findAll().size());
        storageReportRepository.save(report);
    }

    @Override
    public void toggleUserLock(Long userId) {
        Long id = java.util.Objects.requireNonNull(userId, "userId");
        User user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        user.setAccountNonLocked(!user.isAccountNonLocked());
        userRepository.save(user);
    }

    @Override
    public long getTotalUsers() {
        return userRepository.count();
    }

    @Override
    public long getActiveUsers() {
        // For simplicity, count users who are not locked
        return userRepository.findAll().stream().filter(User::isAccountNonLocked).count();
    }

    @Override
    public long getTotalDocuments() {
        return documentRepository.count();
    }

    @Override
    public long getStorageUsed() {
        return documentRepository.findAll().stream().mapToLong(Document::getSizeInBytes).sum();
    }

    @Override
    public long getFailedLoginAttempts() {
        return auditLogRepository.findAll().stream()
                .filter(log -> "FAILED_LOGIN".equals(log.getAction()))
                .count();
    }

    @Override
    public List<String> getSecurityAlerts() {
        List<String> alerts = userRepository.findAll().stream()
                .filter(user -> user.getFailedLoginAttempts() > 3)
                .map(user -> "User " + user.getEmail() + " has " + user.getFailedLoginAttempts() + " failed login attempts.")
                .collect(Collectors.toList());
        // Add more alerts if needed
        return alerts;
    }

    @Override
    public List<User> searchUsers(String query) {
        return userRepository.findByFullNameContainingIgnoreCaseOrEmailContainingIgnoreCase(query, query);
    }

    @Override
    public void changeUserRole(Long userId, Role role) {
        Long id = java.util.Objects.requireNonNull(userId, "userId");
        User user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        if (role == Role.ROLE_ADMIN && !"vaultx89@gmail.com".equalsIgnoreCase(user.getEmail())) {
            throw new IllegalArgumentException("Admin role can only be assigned to vaultx89@gmail.com");
        }
        user.setRole(role);
        userRepository.save(user);
    }

    @Override
    @SuppressWarnings("null")
    public void deleteUser(Long userId) {
        Long id = java.util.Objects.requireNonNull(userId, "userId");
        User user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        userRepository.delete(user);
    }

    @Override
    public List<Document> getDocumentsByType(String type) {
        String normalizedType = type == null ? "" : type;
        return documentRepository.findAll().stream()
                .filter(doc -> normalizedType.equalsIgnoreCase(doc.getContentType()))
                .collect(Collectors.toList());
    }

    @Override
    public List<Document> searchDocumentsByUser(String userEmail) {
        String normalizedEmail = userEmail == null ? "" : userEmail;
        return documentRepository.findAll().stream()
                .filter(doc -> doc.getOwner() != null && normalizedEmail.equalsIgnoreCase(doc.getOwner().getEmail()))
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    @SuppressWarnings("null")
    public void deleteDocument(Long docId) {
        Long id = java.util.Objects.requireNonNull(docId, "docId");
        Document doc = documentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Document not found"));
        recycleBinRepository.deleteByDocumentId(id);
        recycleBinRepository.flush();
        digitalSignatureRepository.deleteByDocumentId(id);
        digitalSignatureRepository.flush();
        documentRepository.delete(doc);
    }

    @Override
    public List<AuditLog> getAllAuditLogs() {
        return auditLogRepository.findAllByOrderByCreatedAtDesc();
    }

    @Override
    public Page<AuditLog> getAuditLogs(Pageable pageable) {
        return auditLogRepository.findAllByOrderByCreatedAtDesc(pageable);
    }

    @Override
    public Page<Document> getDocuments(String type, String userEmail, Pageable pageable) {
        String normalizedType = normalize(type);
        String normalizedEmail = normalize(userEmail);
        if (hasText(normalizedType) && hasText(normalizedEmail)) {
            return documentRepository.findByContentTypeIgnoreCaseAndOwner_EmailContainingIgnoreCaseOrderByCreatedAtDesc(
                    normalizedType,
                    normalizedEmail,
                    pageable
            );
        }
        if (hasText(normalizedType)) {
            return documentRepository.findByContentTypeIgnoreCaseOrderByCreatedAtDesc(normalizedType, pageable);
        }
        if (hasText(normalizedEmail)) {
            return documentRepository.findByOwner_EmailContainingIgnoreCaseOrderByCreatedAtDesc(normalizedEmail, pageable);
        }
        return documentRepository.findAllByOrderByCreatedAtDesc(pageable);
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim();
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }
}
