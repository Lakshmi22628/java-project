package com.vaultx.service.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.vaultx.service.EmailService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EmailServiceImpl implements EmailService {

    private final JavaMailSender mailSender;

    @Value("${spring.mail.from:}")
    private String mailFrom;

    @Override
    public void sendOtpEmail(String email, String fullName, String otp, String purpose) {
        SimpleMailMessage message = new SimpleMailMessage();
        if (mailFrom != null && !mailFrom.isBlank()) {
            message.setFrom(mailFrom);
        }
        message.setTo(email);
        message.setSubject("VaultX " + purpose + " OTP");
        message.setText("Hello " + fullName + ",\n\nYour VaultX OTP is: " + otp + "\nUse it before it expires.\n\nIf this was not you, please reset your password.");
        mailSender.send(message);
    }
}
