package com.vaultx.service;

import com.vaultx.entity.DigitalSignature;
import com.vaultx.entity.Document;

public interface DigitalSignatureService {

    DigitalSignature createSignature(Document document, byte[] fileData, String signerName);

    DigitalSignature verifySignature(Document document, byte[] currentData);
}
