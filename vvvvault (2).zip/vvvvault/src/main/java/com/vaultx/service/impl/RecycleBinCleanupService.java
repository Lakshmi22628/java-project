package com.vaultx.service.impl;

import com.vaultx.entity.Document;
import com.vaultx.entity.RecycleBin;
import com.vaultx.repository.DigitalSignatureRepository;
import com.vaultx.repository.DocumentRepository;
import com.vaultx.repository.RecycleBinRepository;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class RecycleBinCleanupService {

    private final RecycleBinRepository recycleBinRepository;
    private final DocumentRepository documentRepository;
    private final DigitalSignatureRepository digitalSignatureRepository;

    @Scheduled(cron = "0 0 2 * * *")
    @Transactional
    public void purgeExpiredRecycleBinEntries() {
        purgeExpiredRecycleBinEntries(LocalDateTime.now());
    }

    @Transactional
    public void purgeExpiredRecycleBinEntries(LocalDateTime now) {
        List<RecycleBin> expiredEntries = recycleBinRepository.findByRestoreDeadlineBefore(now);
        for (RecycleBin recycleBin : expiredEntries) {
            Document document = recycleBin.getDocument();
            recycleBinRepository.delete(recycleBin);
            recycleBinRepository.flush();
            if (document != null) {
                digitalSignatureRepository.deleteByDocumentId(document.getId());
                digitalSignatureRepository.flush();
                documentRepository.delete(document);
                documentRepository.flush();
            }
        }
    }
}
