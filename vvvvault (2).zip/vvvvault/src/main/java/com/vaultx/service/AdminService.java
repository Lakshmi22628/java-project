package com.vaultx.service;

import com.vaultx.entity.AuditLog;
import com.vaultx.entity.Document;
import com.vaultx.entity.StorageReport;
import com.vaultx.entity.User;
import com.vaultx.enums.Role;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface AdminService {

    List<User> getAllUsers();

    List<Document> getAllDocuments();

    List<StorageReport> getStorageReports();

    void refreshStorageReport();

    void toggleUserLock(Long userId);

    long getTotalUsers();

    long getActiveUsers();

    long getTotalDocuments();

    long getStorageUsed();

    long getFailedLoginAttempts();

    List<String> getSecurityAlerts();

    List<User> searchUsers(String query);

    void changeUserRole(Long userId, Role role);

    void deleteUser(Long userId);

    List<Document> getDocumentsByType(String type);

    List<Document> searchDocumentsByUser(String userEmail);

    void deleteDocument(Long docId);

    List<AuditLog> getAllAuditLogs();

    Page<AuditLog> getAuditLogs(Pageable pageable);

    Page<Document> getDocuments(String type, String userEmail, Pageable pageable);
}
