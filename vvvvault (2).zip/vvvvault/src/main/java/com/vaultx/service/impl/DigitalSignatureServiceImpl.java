package com.vaultx.service.impl;

import com.vaultx.entity.DigitalSignature;
import com.vaultx.entity.Document;
import com.vaultx.enums.VerificationStatus;
import com.vaultx.repository.DigitalSignatureRepository;
import com.vaultx.service.DigitalSignatureService;
import com.vaultx.util.HashUtil;
import java.time.LocalDateTime;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DigitalSignatureServiceImpl implements DigitalSignatureService {

    private final DigitalSignatureRepository digitalSignatureRepository;
    private final HashUtil hashUtil;

    @Override
    public DigitalSignature createSignature(Document document, byte[] fileData, String signerName) {
        DigitalSignature signature = digitalSignatureRepository.findByDocumentId(document.getId()).orElse(new DigitalSignature());
        signature.setDocument(document);
        signature.setSignatureHash(hashUtil.sha256(fileData));
        signature.setSignerName(signerName == null || signerName.isBlank() ? document.getOwner().getFullName() : signerName);
        signature.setVerificationStatus(VerificationStatus.VERIFIED);
        signature.setVerifiedAt(LocalDateTime.now());
        return digitalSignatureRepository.save(signature);
    }

    @Override
    public DigitalSignature verifySignature(Document document, byte[] currentData) {
        DigitalSignature signature = digitalSignatureRepository.findByDocumentId(document.getId())
                .orElseThrow(() -> new IllegalArgumentException("Signature not found"));
        String currentHash = hashUtil.sha256(currentData);
        boolean match = signature.getSignatureHash().equals(currentHash);
        signature.setVerificationStatus(match ? VerificationStatus.VERIFIED : VerificationStatus.FAILED);
        signature.setVerifiedAt(LocalDateTime.now());
        return digitalSignatureRepository.save(signature);
    }
}
