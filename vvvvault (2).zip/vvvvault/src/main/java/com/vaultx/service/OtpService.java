package com.vaultx.service;

import com.vaultx.entity.User;
import com.vaultx.enums.OtpPurpose;
import com.vaultx.enums.OtpValidationResult;

public interface OtpService {

    String generateAndSendOtp(User user, OtpPurpose purpose);

    boolean isEmailDeliveryEnabled();

    OtpValidationResult validateOtp(User user, String otp, OtpPurpose purpose);
}
