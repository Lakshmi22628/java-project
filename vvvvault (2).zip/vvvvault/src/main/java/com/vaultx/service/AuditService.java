package com.vaultx.service;

import com.vaultx.entity.AuditLog;
import com.vaultx.entity.User;
import java.util.List;

public interface AuditService {

    void log(User user, String action, String details, String ipAddress);

    List<AuditLog> getRecentLogs();
}
