package com.vaultx.service.impl;

import com.vaultx.dto.DocumentSearchResult;
import com.vaultx.dto.DocumentUpdateRequest;
import com.vaultx.dto.DocumentUploadRequest;
import com.vaultx.dto.MergePdfRequest;
import com.vaultx.dto.ShareDocumentRequest;
import com.vaultx.entity.Document;
import com.vaultx.entity.DocumentData;
import com.vaultx.entity.DocumentVersion;
import com.vaultx.entity.RecycleBin;
import com.vaultx.entity.SharedDocument;
import com.vaultx.entity.User;
import com.vaultx.repository.DocumentDataRepository;
import com.vaultx.repository.DocumentRepository;
import com.vaultx.repository.DocumentVersionRepository;
import com.vaultx.repository.DigitalSignatureRepository;
import com.vaultx.repository.RecycleBinRepository;
import com.vaultx.repository.SharedDocumentRepository;
import com.vaultx.repository.UserRepository;
import com.vaultx.service.AuditService;
import com.vaultx.service.DigitalSignatureService;
import com.vaultx.service.DocumentService;
import com.vaultx.util.AesEncryptionUtil;
import com.vaultx.util.HashUtil;
import com.vaultx.util.PdfTextExtractor;
import com.vaultx.util.PdfProcessingUtil;
import com.vaultx.util.PresentationProcessingUtil;
import com.vaultx.util.WordProcessingUtil;
import java.time.LocalDateTime;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import javax.crypto.AEADBadTagException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Service
@RequiredArgsConstructor
public class DocumentServiceImpl implements DocumentService {

    private final DocumentRepository documentRepository;
    private final DocumentDataRepository documentDataRepository;
    private final DocumentVersionRepository documentVersionRepository;
    private final DigitalSignatureRepository digitalSignatureRepository;
    private final SharedDocumentRepository sharedDocumentRepository;
    private final RecycleBinRepository recycleBinRepository;
    private final UserRepository userRepository;
    private final AesEncryptionUtil aesEncryptionUtil;
    private final PdfTextExtractor pdfTextExtractor;
    private final PdfProcessingUtil pdfProcessingUtil;
    private final HashUtil hashUtil;
    private final DigitalSignatureService digitalSignatureService;
    private final AuditService auditService;
    private final WordProcessingUtil wordProcessingUtil;
    private final PresentationProcessingUtil presentationProcessingUtil;
    private final RecycleBinCleanupService recycleBinCleanupService;

    private boolean isAdmin(User user) {
        return user != null && com.vaultx.enums.Role.ROLE_ADMIN.equals(user.getRole());
    }

    @Override
    @Transactional
    public Document upload(User user, MultipartFile file, DocumentUploadRequest request) {
        try {
            byte[] bytes = file.getBytes();
            Document document = storeDocument(user, bytes, file.getOriginalFilename(), file.getContentType(), request.getTitle(),
                    request.getCategory(), request.getCustomCategory(), request.getSignerName());
            auditService.log(user, "DOCUMENT_UPLOADED", "Uploaded " + document.getTitle(), null);
            return document;
        } catch (Exception exception) {
            throw new IllegalStateException("Unable to upload document", exception);
        }
    }

    @Override
    @Transactional
    public Document updateVersion(Long documentId, User user, MultipartFile file) {
        try {
            Long id = Objects.requireNonNull(documentId, "documentId");
            Document document = getAccessibleDocument(id, user);
            byte[] bytes = file.getBytes();
            AesEncryptionUtil.EncryptionResult encryptionResult = aesEncryptionUtil.encrypt(bytes);
            DocumentData documentData = documentDataRepository.findByDocumentId(id)
                    .orElseThrow(() -> new IllegalArgumentException("Document data not found"));
            documentData.setEncryptedData(encryptionResult.getEncryptedData());
            documentData.setEncryptionIv(encryptionResult.getIv());
            documentData.setChecksum(hashUtil.sha256(bytes));

            int nextVersion = document.getCurrentVersion() + 1;
            document.setCurrentVersion(nextVersion);
            document.setSizeInBytes(file.getSize());
            document.setOriginalFileName(file.getOriginalFilename());
            document.setExtractedText(pdfTextExtractor.extractText(bytes, file.getContentType(), file.getOriginalFilename()));
            documentRepository.save(document);
            documentDataRepository.save(documentData);
            DocumentVersion version = Objects.requireNonNull(buildVersion(document, nextVersion, file.getOriginalFilename(), file.getSize(), encryptionResult),
                    "documentVersion");
            documentVersionRepository.save(version);
            digitalSignatureService.createSignature(document, bytes, document.getOwner().getFullName());
            auditService.log(user, "DOCUMENT_VERSIONED", "Updated version for " + document.getTitle(), null);
            return document;
        } catch (Exception exception) {
            throw new IllegalStateException("Unable to update document version", exception);
        }
    }

    @Override
    @Transactional
    public Document updateMetadata(Long documentId, User user, DocumentUpdateRequest request) {
        Document document = getAccessibleDocument(Objects.requireNonNull(documentId, "documentId"), user);
        document.setTitle(request.getTitle() == null || request.getTitle().isBlank() ? document.getOriginalFileName() : request.getTitle().trim());
        document.setOriginalFileName(normalizeFileName(request.getOriginalFileName(), document.getOriginalFileName()));
        applyCategory(document, request.getCategory(), request.getCustomCategory());
        Document saved = documentRepository.save(document);
        auditService.log(user, "DOCUMENT_UPDATED", "Updated document details for " + saved.getTitle(), null);
        return saved;
    }

    @Override
    @Transactional
    public Document mergePdfDocuments(User user, MergePdfRequest request) {
        if (request.getDocumentIds() == null || request.getDocumentIds().size() < 2) {
            throw new IllegalArgumentException("Select at least two PDF documents to merge.");
        }
        List<Document> documents = request.getDocumentIds().stream()
                .distinct()
                .map(documentId -> {
                    Document document = getAccessibleDocument(documentId, user);
                    if (!document.getOwner().getId().equals(user.getId())) {
                        throw new IllegalArgumentException("You can only merge PDF files that you uploaded.");
                    }
                    if (!isPdfDocument(document)) {
                        throw new IllegalArgumentException("Only PDF documents can be merged.");
                    }
                    return document;
                })
                .toList();
        List<byte[]> pdfBytes = documents.stream()
                .map(this::loadDocumentBytes)
                .toList();
        byte[] mergedPdf = pdfProcessingUtil.mergePdfDocuments(pdfBytes);
        String title = request.getTitle() == null || request.getTitle().isBlank() ? "Merged PDF Document" : request.getTitle().trim();
        String fileName = title.replaceAll("[^a-zA-Z0-9-_ ]", "").trim().replace(' ', '_');
        if (fileName.isBlank()) {
            fileName = "merged_document";
        }
        Document mergedDocument = storeDocument(user, mergedPdf, fileName + ".pdf", "application/pdf", title,
                com.vaultx.enums.DocumentCategory.OTHER, "Merged PDFs", request.getSignerName());
        auditService.log(user, "DOCUMENT_MERGED", "Merged " + documents.size() + " PDF documents into " + mergedDocument.getTitle(), null);
        return mergedDocument;
    }

    @Override
    @Transactional
    public Document convertImageToPdf(Long documentId, User user, String title, String signerName) {
        Document sourceDocument = getAccessibleDocument(documentId, user);
        if (!sourceDocument.getOwner().getId().equals(user.getId())) {
            throw new IllegalArgumentException("You can only convert files that you uploaded.");
        }
        byte[] sourceBytes = loadDocumentBytes(sourceDocument);
        byte[] pdfBytes;
        if (isImageDocument(sourceDocument)) {
            pdfBytes = pdfProcessingUtil.imageToPdf(sourceBytes, sourceDocument.getOriginalFileName());
        } else if (isTextDocument(sourceDocument)) {
            String text = new String(sourceBytes, StandardCharsets.UTF_8);
            pdfBytes = pdfProcessingUtil.textToPdf(text, sourceDocument.getOriginalFileName());
        } else if (isDocxDocument(sourceDocument)) {
            pdfBytes = wordProcessingUtil.docxToPdf(sourceBytes, sourceDocument.getOriginalFileName());
        } else if (isDocDocument(sourceDocument)) {
            pdfBytes = wordProcessingUtil.docToPdf(sourceBytes, sourceDocument.getOriginalFileName());
        } else if (isPowerPointDocument(sourceDocument)) {
            pdfBytes = presentationProcessingUtil.pptToPdf(sourceBytes, sourceDocument.getOriginalFileName(), sourceDocument.getContentType());
        } else {
            throw new IllegalArgumentException("Only image, text, DOC, DOCX, PPT, or PPTX documents can be converted to PDF.");
        }
        String baseTitle = title == null || title.isBlank() ? sourceDocument.getTitle() + " PDF" : title.trim();
        String baseFileName = sourceDocument.getOriginalFileName();
        int dotIndex = baseFileName.lastIndexOf('.');
        if (dotIndex > 0) {
            baseFileName = baseFileName.substring(0, dotIndex);
        }
        Document convertedDocument = storeDocument(user, pdfBytes, baseFileName + ".pdf", "application/pdf", baseTitle,
                sourceDocument.getCategory(), sourceDocument.getCustomCategory(),
                signerName == null || signerName.isBlank() ? sourceDocument.getOwner().getFullName() : signerName);
        auditService.log(user, "DOCUMENT_CONVERTED_TO_PDF", "Converted document to PDF: " + convertedDocument.getTitle(), null);
        return convertedDocument;
    }

    @Override
    @Transactional
    public Document convertPresentationToPdf(Long documentId, User user, String title) {
        Document sourceDocument = getAccessibleDocument(documentId, user);
        if (!sourceDocument.getOwner().getId().equals(user.getId())) {
            throw new IllegalArgumentException("You can only convert files that you uploaded.");
        }
        if (!isPowerPointDocument(sourceDocument)) {
            throw new IllegalArgumentException("Only PPT or PPTX documents can be converted to PDF.");
        }
        byte[] sourceBytes = loadDocumentBytes(sourceDocument);
        byte[] pdfBytes = presentationProcessingUtil.pptToPdf(sourceBytes, sourceDocument.getOriginalFileName(), sourceDocument.getContentType());
        String baseTitle = title == null || title.isBlank() ? sourceDocument.getTitle() + " PDF" : title.trim();
        String baseFileName = normalizeBaseFileName(sourceDocument.getOriginalFileName());
        Document convertedDocument = storeDocument(user, pdfBytes, baseFileName + ".pdf", "application/pdf", baseTitle,
                sourceDocument.getCategory(), sourceDocument.getCustomCategory(), sourceDocument.getOwner().getFullName());
        auditService.log(user, "DOCUMENT_CONVERTED_TO_PDF", "Converted PowerPoint to PDF: " + convertedDocument.getTitle(), null);
        return convertedDocument;
    }

    @Override
    @Transactional
    public Document convertPdfToDocxDocument(Long documentId, User user, String title) {
        Document sourceDocument = getAccessibleDocument(documentId, user);
        if (!sourceDocument.getOwner().getId().equals(user.getId())) {
            throw new IllegalArgumentException("You can only convert files that you uploaded.");
        }
        if (!isPdfDocument(sourceDocument)) {
            throw new IllegalArgumentException("Only PDF documents can be converted to DOCX.");
        }
        byte[] sourceBytes = loadDocumentBytes(sourceDocument);
        byte[] docxBytes = wordProcessingUtil.pdfToDocx(sourceBytes, sourceDocument.getOriginalFileName());
        String baseTitle = title == null || title.isBlank() ? sourceDocument.getTitle() + " DOCX" : title.trim();
        String baseFileName = normalizeBaseFileName(sourceDocument.getOriginalFileName());
        Document convertedDocument = storeDocument(user, docxBytes, baseFileName + ".docx",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                baseTitle, sourceDocument.getCategory(), sourceDocument.getCustomCategory(),
                sourceDocument.getOwner().getFullName());
        auditService.log(user, "DOCUMENT_CONVERTED_TO_DOCX", "Converted PDF to DOCX: " + convertedDocument.getTitle(), null);
        return convertedDocument;
    }

    @Override
    @Transactional
    public Document convertPdfToTextDocument(Long documentId, User user, String title) {
        Document sourceDocument = getAccessibleDocument(documentId, user);
        if (!sourceDocument.getOwner().getId().equals(user.getId())) {
            throw new IllegalArgumentException("You can only convert files that you uploaded.");
        }
        if (!isPdfDocument(sourceDocument)) {
            throw new IllegalArgumentException("Only PDF documents can be converted to text.");
        }
        String extractedText = pdfTextExtractor.extractText(loadDocumentBytes(sourceDocument),
                sourceDocument.getContentType(), sourceDocument.getOriginalFileName());
        if (extractedText == null || extractedText.isBlank()) {
            throw new IllegalArgumentException("No extractable text was found in this PDF. If this is a scanned PDF, OCR is needed before converting to DOCX.");
        }
        String baseTitle = title == null || title.isBlank() ? sourceDocument.getTitle() + " Text" : title.trim();
        String baseFileName = normalizeBaseFileName(sourceDocument.getOriginalFileName());
        byte[] textBytes = extractedText.getBytes(StandardCharsets.UTF_8);
        Document convertedDocument = storeDocument(user, textBytes, baseFileName + ".txt", "text/plain", baseTitle,
                sourceDocument.getCategory(), sourceDocument.getCustomCategory(), sourceDocument.getOwner().getFullName());
        auditService.log(user, "DOCUMENT_CONVERTED_TO_TEXT", "Converted PDF to text document: " + convertedDocument.getTitle(), null);
        return convertedDocument;
    }

    @Override
    @Transactional
    public List<Document> splitPdfDocument(Long documentId, User user) {
        Document sourceDocument = getAccessibleDocument(documentId, user);
        if (!sourceDocument.getOwner().getId().equals(user.getId())) {
            throw new IllegalArgumentException("You can only split files that you uploaded.");
        }
        if (!isPdfDocument(sourceDocument)) {
            throw new IllegalArgumentException("Only PDF documents can be split.");
        }
        List<byte[]> pages = pdfProcessingUtil.splitPdfDocuments(loadDocumentBytes(sourceDocument));
        if (pages.size() < 2) {
            throw new IllegalArgumentException("This PDF has only one page, so there is nothing to split.");
        }
        String baseName = normalizeBaseFileName(sourceDocument.getOriginalFileName());
        List<Document> splitDocuments = new ArrayList<>();
        for (int index = 0; index < pages.size(); index++) {
            byte[] pageBytes = pages.get(index);
            int pageNumber = index + 1;
            String fileName = baseName + "_page_" + pageNumber + ".pdf";
            String title = sourceDocument.getTitle() + " - Page " + pageNumber;
            splitDocuments.add(storeDocument(user, pageBytes, fileName, "application/pdf", title,
                    sourceDocument.getCategory(), sourceDocument.getCustomCategory(), sourceDocument.getOwner().getFullName()));
        }
        auditService.log(user, "DOCUMENT_SPLIT", "Split " + sourceDocument.getTitle() + " into " + splitDocuments.size() + " PDF pages", null);
        return splitDocuments;
    }

    @Override
    @Transactional
    public Document splitPdfDocument(Long documentId, User user, int startPage, int endPage, String title) {
        Document sourceDocument = getAccessibleDocument(documentId, user);
        if (!sourceDocument.getOwner().getId().equals(user.getId())) {
            throw new IllegalArgumentException("You can only split files that you uploaded.");
        }
        if (!isPdfDocument(sourceDocument)) {
            throw new IllegalArgumentException("Only PDF documents can be split.");
        }
        byte[] pageRangeBytes = pdfProcessingUtil.extractPdfPageRange(loadDocumentBytes(sourceDocument), startPage, endPage);
        String baseTitle = title == null || title.isBlank()
                ? sourceDocument.getTitle() + " Pages " + startPage + "-" + endPage
                : title.trim();
        String baseFileName = normalizeBaseFileName(sourceDocument.getOriginalFileName());
        String rangeSuffix = "_pages_" + startPage + "_to_" + endPage + ".pdf";
        Document extractedDocument = storeDocument(user, pageRangeBytes, baseFileName + rangeSuffix, "application/pdf", baseTitle,
                sourceDocument.getCategory(), sourceDocument.getCustomCategory(), sourceDocument.getOwner().getFullName());
        auditService.log(user, "DOCUMENT_SPLIT_RANGE", "Extracted pages " + startPage + "-" + endPage + " from " + sourceDocument.getTitle(), null);
        return extractedDocument;
    }

    @Override
    @Transactional
    public Document splitPdfDocument(Long documentId, User user, String pageSelection, String title) {
        Document sourceDocument = getAccessibleDocument(documentId, user);
        if (!sourceDocument.getOwner().getId().equals(user.getId())) {
            throw new IllegalArgumentException("You can only split files that you uploaded.");
        }
        if (!isPdfDocument(sourceDocument)) {
            throw new IllegalArgumentException("Only PDF documents can be split.");
        }
        byte[] sourceBytes = loadDocumentBytes(sourceDocument);
        List<Integer> selectedPages = parsePageSelection(pageSelection, pdfProcessingUtil.getPdfPageCount(sourceBytes));
        byte[] selectedBytes = pdfProcessingUtil.extractSpecificPdfPages(sourceBytes, selectedPages);
        int firstPage = selectedPages.get(0);
        int lastPage = selectedPages.get(selectedPages.size() - 1);
        String pageLabel = selectedPages.size() == 1
                ? "Page " + firstPage
                : "Pages " + firstPage + "-" + lastPage;
        String baseTitle = title == null || title.isBlank()
                ? sourceDocument.getTitle() + " " + pageLabel
                : title.trim();
        String baseFileName = normalizeBaseFileName(sourceDocument.getOriginalFileName());
        String suffix = "_pages_" + selectedPages.stream().map(String::valueOf).reduce((first, second) -> first + "_" + second).orElse("selected") + ".pdf";
        Document extractedDocument = storeDocument(user, selectedBytes, baseFileName + suffix, "application/pdf", baseTitle,
                sourceDocument.getCategory(), sourceDocument.getCustomCategory(), sourceDocument.getOwner().getFullName());
        auditService.log(user, "DOCUMENT_SPLIT_SELECTED", "Extracted selected pages from " + sourceDocument.getTitle(), null);
        return extractedDocument;
    }

    @Override
    public int getPdfPageCount(Long documentId, User user) {
        Document sourceDocument = getAccessibleDocument(Objects.requireNonNull(documentId, "documentId"), user);
        if (!isPdfDocument(sourceDocument)) {
            throw new IllegalArgumentException("Only PDF documents can be split.");
        }
        return pdfProcessingUtil.getPdfPageCount(loadDocumentBytes(sourceDocument));
    }

    @Override
    public byte[] download(Long documentId, User user) {
        Document document = getAccessibleDocument(Objects.requireNonNull(documentId, "documentId"), user);
        byte[] decrypted = loadDocumentBytes(document);
        digitalSignatureService.verifySignature(document, decrypted);
        auditService.log(user, "DOCUMENT_DOWNLOADED", "Downloaded " + document.getTitle(), null);
        return decrypted;
    }

    @Override
    public byte[] downloadByQrToken(String qrToken) {
        Document document = getByQrToken(qrToken);
        return loadDocumentBytes(document);
    }

    @Override
    public Document getAccessibleDocument(Long documentId, User user) {
        Long id = Objects.requireNonNull(documentId, "documentId");
        Document document = documentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Document not found"));
        boolean owner = document.getOwner().getId().equals(user.getId());
        boolean shared = sharedDocumentRepository.findBySharedWithUserIdOrderBySharedAtDesc(user.getId())
                .stream()
                .anyMatch(item -> item.getDocument().getId().equals(id));
        boolean admin = isAdmin(user);
        if (!owner && !shared && !admin) {
            throw new IllegalArgumentException("Access denied");
        }
        if (document.getQrToken() == null || document.getQrToken().isBlank()) {
            document.setQrToken(UUID.randomUUID().toString());
            document = documentRepository.save(document);
        }
        return document;
    }

    @Override
    public Document getByQrToken(String qrToken) {
        return documentRepository.findByQrTokenAndDeletedFalse(qrToken)
                .orElseThrow(() -> new IllegalArgumentException("Document not found"));
    }

    @Override
    public List<Document> getMyDocuments(User user) {
        return documentRepository.findByOwnerAndDeletedFalseOrderByUpdatedAtDesc(user);
    }

    @Override
    public List<Document> getMyDocuments(User user, String sortBy, String categoryFilter) {
        return applyDocumentFilters(documentRepository.findByOwnerAndDeletedFalseOrderByUpdatedAtDesc(user), sortBy, categoryFilter);
    }

    @Override
    public List<SharedDocument> getSharedWithMe(User user) {
        return sharedDocumentRepository.findBySharedWithUserIdOrderBySharedAtDesc(user.getId());
    }

    @Override
    public List<SharedDocument> getSharedByMe(User user) {
        return sharedDocumentRepository.findByOwnerIdOrderBySharedAtDesc(user.getId());
    }

    @Override
    public List<DocumentSearchResult> searchDocuments(User user, String keyword) {
        String normalizedKeyword = keyword == null ? "" : keyword.trim();
        if (normalizedKeyword.isBlank()) {
            return List.of();
        }
        return documentRepository.findByDeletedFalseOrderByUpdatedAtDesc()
                .stream()
                .filter(doc -> doc.getOwner().getId().equals(user.getId()) || isAdmin(user))
                .filter(doc -> matchesSearchKeyword(doc, normalizedKeyword))
                .map(doc -> new DocumentSearchResult(doc.getId(), doc.getTitle(), displayCategory(doc), buildSearchSnippet(doc, normalizedKeyword)))
                .toList();
    }

    @Override
    @Transactional
    public void deleteDocument(Long documentId, User user) {
        Document document = getAccessibleDocument(Objects.requireNonNull(documentId, "documentId"), user);
        document.setDeleted(true);
        documentRepository.save(document);

        RecycleBin recycleBin = recycleBinRepository.findByDocumentId(documentId).orElse(new RecycleBin());
        recycleBin.setDocument(document);
        recycleBin.setDeletedBy(user);
        recycleBin.setDeletedAt(LocalDateTime.now());
        recycleBin.setRestoreDeadline(LocalDateTime.now().plusDays(7));
        recycleBinRepository.save(recycleBin);
        auditService.log(user, "DOCUMENT_DELETED", "Moved to recycle bin: " + document.getTitle(), null);
    }

    @Override
    @Transactional
    public void permanentlyDeleteDocument(Long documentId, User user) {
        Document document = getOwnedOrAdminDocument(Objects.requireNonNull(documentId, "documentId"), user);
        String title = document.getTitle();
        recycleBinRepository.deleteByDocumentId(documentId);
        recycleBinRepository.flush();
        digitalSignatureRepository.deleteByDocumentId(documentId);
        digitalSignatureRepository.flush();
        documentRepository.delete(document);
        documentRepository.flush();
        auditService.log(user, "DOCUMENT_PERMANENTLY_DELETED", "Permanently deleted: " + title, null);
    }

    @Override
    @Transactional
    public void restoreDocument(Long documentId, User user) {
        recycleBinCleanupService.purgeExpiredRecycleBinEntries();
        RecycleBin recycleBin = recycleBinRepository.findByDocumentId(documentId)
                .orElseThrow(() -> new IllegalArgumentException("This document has already been permanently deleted after 7 days in the recycle bin."));
        boolean owner = recycleBin.getDeletedBy().getId().equals(user.getId());
        boolean admin = isAdmin(user);
        if (!owner && !admin) {
            throw new IllegalArgumentException("Access denied");
        }
        if (recycleBin.getRestoreDeadline() != null && !recycleBin.getRestoreDeadline().isAfter(LocalDateTime.now())) {
            recycleBinCleanupService.purgeExpiredRecycleBinEntries();
            throw new IllegalArgumentException("This document expired from the recycle bin. Please upload it again.");
        }
        Document document = recycleBin.getDocument();
        document.setDeleted(false);
        documentRepository.save(document);
        recycleBinRepository.delete(recycleBin);
        auditService.log(user, "DOCUMENT_RESTORED", "Restored: " + document.getTitle(), null);
    }

    @Override
    public List<RecycleBin> getRecycleBin(User user) {
        recycleBinCleanupService.purgeExpiredRecycleBinEntries();
        return recycleBinRepository.findByDeletedByIdOrderByDeletedAtDesc(user.getId());
    }

    @Override
    @Transactional
    public SharedDocument shareDocument(Long documentId, User user, ShareDocumentRequest request) {
        Long id = Objects.requireNonNull(documentId, "documentId");
        Document document = getAccessibleDocument(id, user);
        User recipient = userRepository.findByEmail(request.getRecipientEmail().toLowerCase())
                .orElseThrow(() -> new IllegalArgumentException("Recipient not found"));
        if (recipient.getId().equals(user.getId())) {
            throw new IllegalArgumentException("You cannot share a document with yourself");
        }
        SharedDocument sharedDocument = sharedDocumentRepository.findByDocumentIdAndSharedWithUserId(id, recipient.getId())
                .orElse(new SharedDocument());
        sharedDocument.setDocument(document);
        sharedDocument.setOwner(user);
        sharedDocument.setSharedWithUser(recipient);
        sharedDocument.setPermission(request.getPermission());
        auditService.log(user, "DOCUMENT_SHARED", "Shared " + document.getTitle() + " with " + recipient.getEmail(), null);
        return sharedDocumentRepository.save(sharedDocument);
    }

    @Override
    public List<DocumentVersion> getVersions(Long documentId, User user) {
        Long id = Objects.requireNonNull(documentId, "documentId");
        getAccessibleDocument(id, user);
        return documentVersionRepository.findByDocumentIdOrderByVersionNumberDesc(id);
    }

    @Override
    public List<String> getAvailableCategories(User user) {
        return documentRepository.findByOwnerAndDeletedFalseOrderByUpdatedAtDesc(user).stream()
                .map(this::displayCategory)
                .filter(category -> category != null && !category.isBlank())
                .distinct()
                .sorted(String.CASE_INSENSITIVE_ORDER)
                .toList();
    }

    private DocumentVersion buildVersion(Document document, int versionNumber, String fileName, long size,
                                         AesEncryptionUtil.EncryptionResult encryptionResult) {
        DocumentVersion version = new DocumentVersion();
        version.setDocument(document);
        version.setVersionNumber(versionNumber);
        version.setFileName(fileName);
        version.setEncryptedData(encryptionResult.getEncryptedData());
        version.setEncryptionIv(encryptionResult.getIv());
        version.setSizeInBytes(size);
        return version;
    }

    private String buildSnippet(String text, String keyword) {
        if (text == null || text.isBlank()) {
            return "No extracted preview available";
        }
        String normalized = text.replaceAll("\\s+", " ");
        int index = normalized.toLowerCase().indexOf(keyword.toLowerCase());
        if (index < 0) {
            return normalized.substring(0, Math.min(120, normalized.length()));
        }
        int start = Math.max(0, index - 40);
        int end = Math.min(normalized.length(), index + 80);
        return normalized.substring(start, end);
    }

    private boolean matchesSearchKeyword(Document document, String keyword) {
        String lowerKeyword = keyword.toLowerCase();
        return containsIgnoreCase(document.getTitle(), lowerKeyword)
                || containsIgnoreCase(document.getOriginalFileName(), lowerKeyword)
                || containsIgnoreCase(document.getExtractedText(), lowerKeyword)
                || containsIgnoreCase(document.getCustomCategory(), lowerKeyword)
                || containsIgnoreCase(displayCategory(document), lowerKeyword);
    }

    private String buildSearchSnippet(Document document, String keyword) {
        String lowerKeyword = keyword.toLowerCase();
        if (containsIgnoreCase(document.getTitle(), lowerKeyword)) {
            return "Matched document title: " + document.getTitle();
        }
        if (containsIgnoreCase(document.getOriginalFileName(), lowerKeyword)) {
            return "Matched file name: " + document.getOriginalFileName();
        }
        if (containsIgnoreCase(document.getCustomCategory(), lowerKeyword)) {
            return "Matched category: " + document.getCustomCategory();
        }
        if (containsIgnoreCase(displayCategory(document), lowerKeyword)) {
            return "Matched category: " + displayCategory(document);
        }
        return buildSnippet(document.getExtractedText(), keyword);
    }

    private boolean containsIgnoreCase(String value, String keyword) {
        return value != null && !value.isBlank() && value.toLowerCase().contains(keyword);
    }

    private Document getOwnedOrAdminDocument(Long documentId, User user) {
        Document document = documentRepository.findById(documentId)
                .orElseThrow(() -> new IllegalArgumentException("Document not found"));
        boolean owner = document.getOwner().getId().equals(user.getId());
        boolean admin = isAdmin(user);
        if (!owner && !admin) {
            throw new IllegalArgumentException("Only the owner can permanently delete this document.");
        }
        return document;
    }

    private byte[] loadDocumentBytes(Document document) {
        DocumentData data = documentDataRepository.findByDocumentId(document.getId())
                .orElseThrow(() -> new IllegalArgumentException("Document file not found"));
        try {
            return aesEncryptionUtil.decrypt(data.getEncryptedData(), data.getEncryptionIv());
        } catch (IllegalStateException exception) {
            if (isDecryptionFailure(exception)) {
                throw new IllegalArgumentException(
                        "This document cannot be decrypted with the current vault key. Restore the old AES secret or re-upload the file.");
            }
            throw exception;
        }
    }

    private boolean isDecryptionFailure(Throwable exception) {
        Throwable current = exception;
        while (current != null) {
            if (current instanceof AEADBadTagException) {
                return true;
            }
            current = current.getCause();
        }
        return false;
    }

    private Document storeDocument(User user, byte[] bytes, String originalFileName, String contentType, String title,
                                   com.vaultx.enums.DocumentCategory category, String customCategory, String signerName) {
        AesEncryptionUtil.EncryptionResult encryptionResult = aesEncryptionUtil.encrypt(bytes);

        Document document = new Document();
        document.setOwner(user);
        document.setTitle(title == null || title.isBlank() ? originalFileName : title.trim());
        document.setOriginalFileName(originalFileName);
        document.setContentType(contentType);
        applyCategory(document, category, customCategory);
        document.setSizeInBytes((long) bytes.length);
        document.setQrToken(UUID.randomUUID().toString());
        document.setExtractedText(pdfTextExtractor.extractText(bytes, contentType, originalFileName));
        document = documentRepository.save(document);

        DocumentData documentData = new DocumentData();
        documentData.setDocument(document);
        documentData.setEncryptedData(encryptionResult.getEncryptedData());
        documentData.setEncryptionIv(encryptionResult.getIv());
        documentData.setChecksum(hashUtil.sha256(bytes));
        documentDataRepository.save(documentData);

        DocumentVersion version = Objects.requireNonNull(buildVersion(document, 1, originalFileName, bytes.length, encryptionResult),
                "documentVersion");
        documentVersionRepository.save(version);
        digitalSignatureService.createSignature(document, bytes, signerName);
        return document;
    }

    private boolean isPdfDocument(Document document) {
        String contentType = document.getContentType() == null ? "" : document.getContentType().toLowerCase();
        return contentType.equals("application/pdf") || document.getOriginalFileName().toLowerCase().endsWith(".pdf");
    }

    private boolean isTextDocument(Document document) {
        String contentType = document.getContentType() == null ? "" : document.getContentType().toLowerCase();
        String fileName = document.getOriginalFileName() == null ? "" : document.getOriginalFileName().toLowerCase();
        return contentType.startsWith("text/")
                || fileName.endsWith(".txt")
                || fileName.endsWith(".md")
                || fileName.endsWith(".csv")
                || fileName.endsWith(".log");
    }

    private boolean isImageDocument(Document document) {
        String contentType = document.getContentType() == null ? "" : document.getContentType().toLowerCase();
        return contentType.startsWith("image/");
    }

    private boolean isDocxDocument(Document document) {
        String contentType = document.getContentType() == null ? "" : document.getContentType().toLowerCase();
        String fileName = document.getOriginalFileName() == null ? "" : document.getOriginalFileName().toLowerCase();
        return contentType.equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document")
                || fileName.endsWith(".docx");
    }

    private boolean isDocDocument(Document document) {
        String contentType = document.getContentType() == null ? "" : document.getContentType().toLowerCase();
        String fileName = document.getOriginalFileName() == null ? "" : document.getOriginalFileName().toLowerCase();
        return contentType.equals("application/msword") || fileName.endsWith(".doc");
    }

    private boolean isPowerPointDocument(Document document) {
        String contentType = document.getContentType() == null ? "" : document.getContentType().toLowerCase();
        String fileName = document.getOriginalFileName() == null ? "" : document.getOriginalFileName().toLowerCase();
        return contentType.equals("application/vnd.ms-powerpoint")
                || contentType.equals("application/vnd.openxmlformats-officedocument.presentationml.presentation")
                || fileName.endsWith(".ppt")
                || fileName.endsWith(".pptx");
    }

    private String normalizeBaseFileName(String originalFileName) {
        String baseName = originalFileName == null ? "document" : originalFileName;
        int dotIndex = baseName.lastIndexOf('.');
        if (dotIndex > 0) {
            baseName = baseName.substring(0, dotIndex);
        }
        String sanitized = baseName.replaceAll("[^a-zA-Z0-9-_ ]", "").trim().replace(' ', '_');
        return sanitized.isBlank() ? "document" : sanitized;
    }

    private String normalizeFileName(String requestedFileName, String currentFileName) {
        String fallback = currentFileName == null || currentFileName.isBlank() ? "document" : currentFileName.trim();
        String requested = requestedFileName == null ? "" : requestedFileName.trim();
        if (requested.isBlank()) {
            return fallback;
        }

        String candidate = requested.replace("\\", "/");
        int slashIndex = candidate.lastIndexOf('/');
        if (slashIndex >= 0) {
            candidate = candidate.substring(slashIndex + 1);
        }

        String currentExtension = "";
        int fallbackDotIndex = fallback.lastIndexOf('.');
        if (fallbackDotIndex > 0 && fallbackDotIndex < fallback.length() - 1) {
            currentExtension = fallback.substring(fallbackDotIndex);
        }

        String requestedExtension = "";
        int dotIndex = candidate.lastIndexOf('.');
        if (dotIndex > 0 && dotIndex < candidate.length() - 1) {
            requestedExtension = candidate.substring(dotIndex);
            candidate = candidate.substring(0, dotIndex);
        }

        String sanitizedBase = candidate.replaceAll("[^a-zA-Z0-9-_ ]", "").trim().replace(' ', '_');
        if (sanitizedBase.isBlank()) {
            sanitizedBase = "document";
        }

        String extension = requestedExtension.isBlank() ? currentExtension : requestedExtension;
        return extension.isBlank() ? sanitizedBase : sanitizedBase + extension;
    }

    private void applyCategory(Document document, com.vaultx.enums.DocumentCategory category, String customCategory) {
        String normalizedCustomCategory = customCategory == null ? "" : customCategory.trim();
        if (!normalizedCustomCategory.isBlank()) {
            document.setCategory(com.vaultx.enums.DocumentCategory.OTHER);
            document.setCustomCategory(normalizedCustomCategory);
            return;
        }
        document.setCategory(category == null ? com.vaultx.enums.DocumentCategory.OTHER : category);
        document.setCustomCategory(null);
    }

    private List<Document> applyDocumentFilters(List<Document> documents, String sortBy, String categoryFilter) {
        return documents.stream()
                .filter(document -> matchesCategory(document, categoryFilter))
                .sorted(buildComparator(sortBy))
                .toList();
    }

    private boolean matchesCategory(Document document, String categoryFilter) {
        if (categoryFilter == null || categoryFilter.isBlank() || "ALL".equalsIgnoreCase(categoryFilter)) {
            return true;
        }
        return displayCategory(document).equalsIgnoreCase(categoryFilter.trim());
    }

    private Comparator<Document> buildComparator(String sortBy) {
        if ("dateAsc".equalsIgnoreCase(sortBy)) {
            return Comparator.comparing(Document::getCreatedAt, Comparator.nullsLast(Comparator.naturalOrder()));
        }
        if ("categoryAsc".equalsIgnoreCase(sortBy)) {
            return Comparator.comparing(this::displayCategory, String.CASE_INSENSITIVE_ORDER)
                    .thenComparing(Document::getCreatedAt, Comparator.nullsLast(Comparator.reverseOrder()));
        }
        if ("categoryDesc".equalsIgnoreCase(sortBy)) {
            return Comparator.comparing(this::displayCategory, String.CASE_INSENSITIVE_ORDER.reversed())
                    .thenComparing(Document::getCreatedAt, Comparator.nullsLast(Comparator.reverseOrder()));
        }
        return Comparator.comparing(Document::getCreatedAt, Comparator.nullsLast(Comparator.reverseOrder()));
    }

    private String displayCategory(Document document) {
        if (document.getCustomCategory() != null && !document.getCustomCategory().isBlank()) {
            return document.getCustomCategory();
        }
        return document.getCategory() == null ? "OTHER" : document.getCategory().name();
    }

    private List<Integer> parsePageSelection(String pageSelection, int pageCount) {
        if (pageSelection == null || pageSelection.isBlank()) {
            throw new IllegalArgumentException("Enter at least one page number or range.");
        }
        LinkedHashSet<Integer> pages = new LinkedHashSet<>();
        String[] segments = pageSelection.split(",");
        for (String rawSegment : segments) {
            String segment = rawSegment.trim();
            if (segment.isBlank()) {
                continue;
            }
            if (segment.contains("-")) {
                String[] bounds = segment.split("-", 2);
                if (bounds.length != 2 || bounds[0].isBlank() || bounds[1].isBlank()) {
                    throw new IllegalArgumentException("Use page entries like 1,3,5-7.");
                }
                int start = parsePositivePage(bounds[0].trim());
                int end = parsePositivePage(bounds[1].trim());
                if (end < start) {
                    throw new IllegalArgumentException("Range pages must go from a smaller number to a larger number.");
                }
                for (int page = start; page <= end; page++) {
                    validatePageWithinLimit(page, pageCount);
                    pages.add(page);
                }
            } else {
                int page = parsePositivePage(segment);
                validatePageWithinLimit(page, pageCount);
                pages.add(page);
            }
        }
        if (pages.isEmpty()) {
            throw new IllegalArgumentException("Enter at least one page number or range.");
        }
        return List.copyOf(pages);
    }

    private int parsePositivePage(String value) {
        try {
            int page = Integer.parseInt(value);
            if (page < 1) {
                throw new IllegalArgumentException("Page numbers must start at 1.");
            }
            return page;
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException("Use only page numbers and ranges like 1,3,5-7.");
        }
    }

    private void validatePageWithinLimit(int page, int pageCount) {
        if (pageCount > 0 && page > pageCount) {
            throw new IllegalArgumentException("One or more selected pages exceed the number of pages in this PDF.");
        }
    }
}
