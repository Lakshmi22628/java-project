package com.vaultx.service;

public interface EmailService {

    void sendOtpEmail(String email, String fullName, String otp, String purpose);
}
