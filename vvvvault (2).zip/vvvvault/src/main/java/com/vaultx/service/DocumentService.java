package com.vaultx.service;

import com.vaultx.dto.DocumentSearchResult;
import com.vaultx.dto.DocumentUpdateRequest;
import com.vaultx.dto.DocumentUploadRequest;
import com.vaultx.dto.MergePdfRequest;
import com.vaultx.dto.ShareDocumentRequest;
import com.vaultx.entity.Document;
import com.vaultx.entity.DocumentVersion;
import com.vaultx.entity.RecycleBin;
import com.vaultx.entity.SharedDocument;
import com.vaultx.entity.User;
import java.util.List;
import org.springframework.web.multipart.MultipartFile;

public interface DocumentService {

    Document upload(User user, MultipartFile file, DocumentUploadRequest request);

    Document updateMetadata(Long documentId, User user, DocumentUpdateRequest request);

    Document mergePdfDocuments(User user, MergePdfRequest request);

    Document convertImageToPdf(Long documentId, User user, String title, String signerName);

    Document convertPresentationToPdf(Long documentId, User user, String title);

    Document convertPdfToDocxDocument(Long documentId, User user, String title);

    Document convertPdfToTextDocument(Long documentId, User user, String title);

    List<Document> splitPdfDocument(Long documentId, User user);

    Document splitPdfDocument(Long documentId, User user, int startPage, int endPage, String title);

    Document splitPdfDocument(Long documentId, User user, String pageSelection, String title);

    int getPdfPageCount(Long documentId, User user);

    Document updateVersion(Long documentId, User user, MultipartFile file);

    byte[] download(Long documentId, User user);

    byte[] downloadByQrToken(String qrToken);

    Document getAccessibleDocument(Long documentId, User user);

    Document getByQrToken(String qrToken);

    List<Document> getMyDocuments(User user);

    List<Document> getMyDocuments(User user, String sortBy, String categoryFilter);

    List<SharedDocument> getSharedWithMe(User user);

    List<SharedDocument> getSharedByMe(User user);

    List<DocumentSearchResult> searchDocuments(User user, String keyword);

    void deleteDocument(Long documentId, User user);

    void permanentlyDeleteDocument(Long documentId, User user);

    void restoreDocument(Long documentId, User user);

    List<RecycleBin> getRecycleBin(User user);

    SharedDocument shareDocument(Long documentId, User user, ShareDocumentRequest request);

    List<DocumentVersion> getVersions(Long documentId, User user);

    List<String> getAvailableCategories(User user);
}
