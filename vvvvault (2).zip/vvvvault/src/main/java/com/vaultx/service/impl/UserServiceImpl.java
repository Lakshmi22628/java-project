package com.vaultx.service.impl;

import com.vaultx.dto.RegistrationRequest;
import com.vaultx.entity.User;
import com.vaultx.enums.Role;
import com.vaultx.repository.UserRepository;
import com.vaultx.service.UserService;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public User register(RegistrationRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new IllegalArgumentException("Email is already registered");
        }
        User user = new User();
        user.setFullName(request.getFullName());
        user.setEmail(request.getEmail().toLowerCase());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(Role.ROLE_USER);
        user.setEmailVerified(true);
        return userRepository.save(user);
    }

    @Override
    public User getByEmail(String email) {
        return userRepository.findByEmail(email.toLowerCase())
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
    }

    @Override
    public User getById(Long id) {
        return userRepository.findById(Objects.requireNonNull(id, "id"))
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public boolean existsByEmail(String email) {
        return userRepository.existsByEmail(email.toLowerCase());
    }

    @Override
    public void updatePassword(String email, String rawPassword) {
        User user = getByEmail(email);
        user.setPassword(passwordEncoder.encode(rawPassword));
        userRepository.save(user);
    }

    @Override
    public User updateProfile(Long userId, String fullName, MultipartFile profilePicture) {
        byte[] pictureBytes = null;
        String pictureContentType = null;
        if (profilePicture != null && !profilePicture.isEmpty()) {
            try {
                pictureBytes = profilePicture.getBytes();
                pictureContentType = profilePicture.getContentType();
            } catch (Exception exception) {
                throw new IllegalStateException("Failed to save profile picture", exception);
            }
        }
        return updateProfilePicture(userId, fullName, pictureBytes, pictureContentType);
    }

    @Override
    public User updateProfilePicture(Long userId, String fullName, byte[] profilePicture, String contentType) {
        User user = getById(userId);
        String sanitizedName = fullName == null ? "" : fullName.trim();
        if (sanitizedName.isEmpty()) {
            throw new IllegalArgumentException("Full name cannot be empty");
        }
        user.setFullName(sanitizedName);
        if (profilePicture != null && profilePicture.length > 0) {
            String normalizedContentType = contentType == null ? "" : contentType.toLowerCase();
            if (!normalizedContentType.startsWith("image/")) {
                throw new IllegalArgumentException("Profile picture must be an image");
            }
            user.setProfilePicture(profilePicture);
            user.setProfilePictureContentType(contentType);
        }
        return userRepository.save(user);
    }

    @Override
    public User updateProfileDetails(Long userId, String fullName, LocalDate dateOfBirth, String gender) {
        User user = getById(userId);
        String sanitizedName = fullName == null ? "" : fullName.trim();
        if (sanitizedName.isEmpty()) {
            throw new IllegalArgumentException("Full name cannot be empty");
        }
        user.setFullName(sanitizedName);
        user.setDateOfBirth(dateOfBirth);
        user.setGender(gender == null || gender.isBlank() ? null : gender.trim());
        return userRepository.save(user);
    }

    @Override
    public User updateProfileAvatar(Long userId, String profileAvatar) {
        User user = getById(userId);
        String normalizedAvatar = profileAvatar == null ? null : profileAvatar.trim();
        if (normalizedAvatar != null && normalizedAvatar.isBlank()) {
            normalizedAvatar = null;
        }
        user.setProfileAvatar(normalizedAvatar);
        return userRepository.save(user);
    }

    @Override
    public void changePassword(Long userId, String currentPassword, String newPassword) {
        User user = getById(userId);
        if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
            throw new IllegalArgumentException("Current password is incorrect");
        }
        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);
    }
}
