package com.vaultx.service.impl;

import java.time.LocalDateTime;
import java.util.Random;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vaultx.entity.OtpVerification;
import com.vaultx.entity.User;
import com.vaultx.enums.OtpPurpose;
import com.vaultx.enums.OtpValidationResult;
import com.vaultx.repository.OtpVerificationRepository;
import com.vaultx.service.EmailService;
import com.vaultx.service.OtpService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class OtpServiceImpl implements OtpService {

    private final OtpVerificationRepository otpVerificationRepository;
    private final EmailService emailService;

    @Value("${vaultx.security.otp-expiry-minutes:5}")
    private long otpExpiryMinutes;

    @Value("${spring.mail.username:}")
    private String mailUsername;

    @Value("${spring.mail.password:}")
    private String mailPassword;

    @Value("${spring.mail.host:}")
    private String mailHost;

    @Override
    @Transactional
    public String generateAndSendOtp(User user, OtpPurpose purpose) {
        otpVerificationRepository.deleteExpiredOtps(LocalDateTime.now());
        otpVerificationRepository.invalidateActiveOtps(user, purpose);
        String code = String.format("%06d", new Random().nextInt(1_000_000));
        OtpVerification otp = new OtpVerification();
        otp.setUser(user);
        otp.setOtpCode(code);
        otp.setPurpose(purpose);
        otp.setExpiresAt(LocalDateTime.now().plusMinutes(otpExpiryMinutes));
        if (!isEmailDeliveryEnabled()) {
            throw new IllegalStateException("Email delivery is not configured. Set MAIL_USERNAME and MAIL_PASSWORD before logging in.");
        }

        otpVerificationRepository.save(otp);
        try {
            emailService.sendOtpEmail(user.getEmail(), user.getFullName(), code, purpose.name());
        } catch (MailException exception) {
            throw new IllegalStateException("Unable to send OTP email. Check mail server configuration.", exception);
        }

        return code;
    }

    @Override
    public boolean isEmailDeliveryEnabled() {
        return mailHost != null && !mailHost.isBlank()
                && mailUsername != null && !mailUsername.isBlank()
                && mailPassword != null && !mailPassword.isBlank();
    }

    @Override
    @Transactional
    public OtpValidationResult validateOtp(User user, String otp, OtpPurpose purpose) {
        return otpVerificationRepository.findTopByUserAndPurposeAndUsedFalseOrderByCreatedAtDesc(user, purpose)
                .map(entry -> {
                    if (entry.getExpiresAt().isBefore(LocalDateTime.now()) || entry.getExpiresAt().isEqual(LocalDateTime.now())) {
                        entry.setUsed(true);
                        otpVerificationRepository.save(entry);
                        return OtpValidationResult.EXPIRED;
                    }
                    if (!entry.getOtpCode().equals(otp)) {
                        return OtpValidationResult.INVALID;
                    }
                    entry.setUsed(true);
                    otpVerificationRepository.save(entry);
                    return OtpValidationResult.VALID;
                })
                .orElse(OtpValidationResult.NOT_FOUND);
    }
}
