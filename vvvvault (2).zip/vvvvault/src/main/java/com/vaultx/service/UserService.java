package com.vaultx.service;

import com.vaultx.dto.RegistrationRequest;
import com.vaultx.entity.User;
import java.time.LocalDate;
import java.util.List;
import org.springframework.web.multipart.MultipartFile;

public interface UserService {

    User register(RegistrationRequest request);

    User getByEmail(String email);

    User getById(Long id);

    List<User> getAllUsers();

    boolean existsByEmail(String email);

    void updatePassword(String email, String rawPassword);

    User updateProfile(Long userId, String fullName, MultipartFile profilePicture);

    User updateProfilePicture(Long userId, String fullName, byte[] profilePicture, String contentType);

    User updateProfileDetails(Long userId, String fullName, LocalDate dateOfBirth, String gender);

    User updateProfileAvatar(Long userId, String profileAvatar);

    void changePassword(Long userId, String currentPassword, String newPassword);
}
