package com.vaultx.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import jakarta.servlet.http.HttpServletRequest;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler({MaxUploadSizeExceededException.class, MultipartException.class, IllegalStateException.class})
    public RedirectView handleMultipartUploadErrors(HttpServletRequest request,
                                                   Exception exception,
                                                   RedirectAttributes redirectAttributes) {
        String requestUri = request.getRequestURI();
        boolean isProfileUpload = requestUri.contains("/profile");
        boolean isDocumentUpload = requestUri.contains("/documents");

        if (isProfileUpload) {
            redirectAttributes.addFlashAttribute("errorMessage",
                    "Profile picture upload failed. Please choose a smaller JPG or PNG image and try again.");
            RedirectView redirectView = new RedirectView("/profile");
            redirectView.setExposeModelAttributes(false);
            return redirectView;
        }

        redirectAttributes.addFlashAttribute("errorMessage",
                "Document upload failed. Please choose a smaller file or try again.");
        RedirectView redirectView = new RedirectView(isDocumentUpload ? "/documents/upload-page" : "/documents");
        redirectView.setExposeModelAttributes(false);
        return redirectView;
    }
}
