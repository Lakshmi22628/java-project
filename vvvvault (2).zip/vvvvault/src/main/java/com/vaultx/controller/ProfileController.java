package com.vaultx.controller;

import com.vaultx.entity.User;
import com.vaultx.security.CustomUserDetails;
import com.vaultx.service.UserService;
import java.time.LocalDate;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequiredArgsConstructor
public class ProfileController {

    private final UserService userService;

    @GetMapping("/profile")
    public String profilePage(@AuthenticationPrincipal CustomUserDetails principal,
                              Model model) {
        User user = currentUser(principal);
        model.addAttribute("profileUser", user);
        return "document/profile";
    }

    @PostMapping("/profile/details")
    public String updateProfileDetails(@AuthenticationPrincipal CustomUserDetails principal,
                                       @RequestParam("fullName") String fullName,
                                       @RequestParam(value = "dateOfBirth", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateOfBirth,
                                       @RequestParam(value = "gender", required = false) String gender,
                                       RedirectAttributes redirectAttributes) {
        User user = currentUser(principal);
        try {
            userService.updateProfileDetails(user.getId(), fullName, dateOfBirth, gender);
            redirectAttributes.addFlashAttribute("successMessage", "Profile details updated successfully.");
        } catch (IllegalArgumentException exception) {
            redirectAttributes.addFlashAttribute("errorMessage", exception.getMessage());
        }
        return "redirect:/profile";
    }

    @PostMapping("/profile/password")
    public String updatePassword(@AuthenticationPrincipal CustomUserDetails principal,
                                 @RequestParam("currentPassword") String currentPassword,
                                 @RequestParam("newPassword") String newPassword,
                                 @RequestParam("confirmPassword") String confirmPassword,
                                 RedirectAttributes redirectAttributes) {
        User user = currentUser(principal);
        try {
            if (newPassword == null || newPassword.length() < 8) {
                throw new IllegalArgumentException("New password must be at least 8 characters long.");
            }
            if (!newPassword.equals(confirmPassword)) {
                throw new IllegalArgumentException("New password and confirm password must match.");
            }
            userService.changePassword(user.getId(), currentPassword, newPassword);
            redirectAttributes.addFlashAttribute("successMessage", "Password updated successfully.");
        } catch (IllegalArgumentException exception) {
            redirectAttributes.addFlashAttribute("errorMessage", exception.getMessage());
        }
        return "redirect:/profile";
    }

    private User currentUser(CustomUserDetails principal) {
        if (principal == null) {
            throw new IllegalArgumentException("Please sign in first.");
        }
        return userService.getById(principal.getId());
    }
}
