package com.vaultx.controller;

import com.vaultx.dto.DocumentCategoryFolder;
import com.vaultx.dto.DocumentUpdateRequest;
import com.vaultx.dto.DocumentUploadRequest;
import com.vaultx.dto.MergePdfRequest;
import com.vaultx.dto.ShareDocumentRequest;
import com.vaultx.entity.Document;
import com.vaultx.entity.SharedDocument;
import com.vaultx.entity.User;
import com.vaultx.enums.DocumentCategory;
import com.vaultx.security.CustomUserDetails;
import com.vaultx.service.DocumentService;
import com.vaultx.service.UserService;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.MediaTypeFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.data.domain.Page;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/documents")
@RequiredArgsConstructor
public class DocumentController {

    private static final int USER_PAGE_SIZE = 15;
    private static final int SHARED_PAGE_SIZE = 5;
    private final DocumentService documentService;
    private final UserService userService;

    @GetMapping
    public String documentsPage(@AuthenticationPrincipal CustomUserDetails principal,
                                @RequestParam(value = "sortBy", defaultValue = "dateDesc") String sortBy,
                                @RequestParam(value = "category", defaultValue = "ALL") String category,
                                @RequestParam(defaultValue = "0") int page,
                                Model model) {
        User user = currentUser(principal);
        populateDocumentModel(model, user, sortBy, category);
        List<Document> filteredDocuments = documentService.getMyDocuments(user, sortBy, category);
        applyPaging(model, filteredDocuments, page);
        model.addAttribute("selectedPage", Math.max(page, 0));
        return "document/list";
    }

    @GetMapping("/upload-page")
    public String uploadPage(@AuthenticationPrincipal CustomUserDetails principal, Model model) {
        User user = currentUser(principal);
        populateDocumentModel(model, user, "dateDesc", "ALL");
        if (!model.containsAttribute("documentUploadRequest")) {
            model.addAttribute("documentUploadRequest", new DocumentUploadRequest());
        }
        return "document/upload";
    }

    @GetMapping("/search-page")
    public String searchPage(@AuthenticationPrincipal CustomUserDetails principal,
                             @RequestParam(value = "keyword", required = false) String keyword,
                             Model model) {
        User user = currentUser(principal);
        populateDocumentModel(model, user, "dateDesc", "ALL");
        String safeKeyword = keyword == null ? "" : keyword.trim();
        model.addAttribute("keyword", safeKeyword);
        model.addAttribute("results", safeKeyword.isBlank()
                ? java.util.Collections.emptyList()
                : documentService.searchDocuments(user, safeKeyword));
        return "document/search-page";
    }

    @GetMapping("/sort-page")
    public String sortPage(@AuthenticationPrincipal CustomUserDetails principal,
                           @RequestParam(value = "sortBy", defaultValue = "dateDesc") String sortBy,
                           @RequestParam(value = "category", defaultValue = "ALL") String category,
                           @RequestParam(defaultValue = "0") int page,
                           Model model) {
        User user = currentUser(principal);
        populateDocumentModel(model, user, sortBy, category);
        List<Document> filteredDocuments = documentService.getMyDocuments(user, sortBy, category);
        applyPaging(model, filteredDocuments, page);
        model.addAttribute("selectedPage", Math.max(page, 0));
        return "document/sort";
    }

    @GetMapping("/tools")
    public String toolsPage(@AuthenticationPrincipal CustomUserDetails principal, Model model) {
        User user = currentUser(principal);
        populateDocumentModel(model, user, "dateDesc", "ALL");
        return "document/tools";
    }

    @GetMapping("/shared")
    public String sharedWithMePage(@AuthenticationPrincipal CustomUserDetails principal, Model model) {
        User user = currentUser(principal);
        model.addAttribute("sharedDocuments", documentService.getSharedWithMe(user));
        return "document/shared";
    }

    @GetMapping("/shared-by-me")
    public String sharedByMePage(@AuthenticationPrincipal CustomUserDetails principal,
                                 @RequestParam(defaultValue = "0") int page,
                                 Model model) {
        User user = currentUser(principal);
        List<SharedDocument> sharedDocuments = documentService.getSharedByMe(user);
        applySharedPaging(model, sharedDocuments, page);
        return "document/shared-by-me";
    }

    @GetMapping("/recycle-bin")
    public String recycleBinPage(@AuthenticationPrincipal CustomUserDetails principal, Model model) {
        User user = currentUser(principal);
        model.addAttribute("recycleBin", documentService.getRecycleBin(user));
        return "document/recycle-bin";
    }

    @GetMapping("/tools/merge")
    public String mergeToolPage(@AuthenticationPrincipal CustomUserDetails principal, Model model) {
        User user = currentUser(principal);
        populateDocumentModel(model, user, "dateDesc", "ALL");
        model.addAttribute("mergePdfRequest", new MergePdfRequest());
        return "document/merge";
    }

    @GetMapping("/tools/convert")
    public String convertToolPage(@AuthenticationPrincipal CustomUserDetails principal, Model model) {
        User user = currentUser(principal);
        populateDocumentModel(model, user, "dateDesc", "ALL");
        return "document/convert";
    }

    @GetMapping("/tools/split")
    public String splitToolPage(@AuthenticationPrincipal CustomUserDetails principal, Model model) {
        User user = currentUser(principal);
        populateDocumentModel(model, user, "dateDesc", "ALL");
        return "document/split";
    }

    @GetMapping("/{id}/manage")
    public String managePage(@AuthenticationPrincipal CustomUserDetails principal,
                             @PathVariable Long id,
                             Model model) {
        User user = currentUser(principal);
        model.addAttribute("document", documentService.getAccessibleDocument(id, user));
        return "document/manage";
    }

    @PostMapping("/upload")
    public String upload(@AuthenticationPrincipal CustomUserDetails principal,
                         @RequestParam("file") MultipartFile file,
                         @ModelAttribute DocumentUploadRequest request,
                         RedirectAttributes redirectAttributes) {
        User user = currentUser(principal);
        documentService.upload(user, file, request);
        redirectAttributes.addFlashAttribute("successMessage", "Document uploaded securely.");
        return "redirect:/documents";
    }

    @GetMapping("/{id}/edit")
    public String editPage(@AuthenticationPrincipal CustomUserDetails principal,
                           @PathVariable Long id,
                           Model model) {
        User user = currentUser(principal);
        Document document = documentService.getAccessibleDocument(id, user);
        DocumentUpdateRequest request = new DocumentUpdateRequest();
        request.setTitle(document.getTitle());
        request.setOriginalFileName(document.getOriginalFileName());
        request.setCategory(document.getCategory());
        request.setCustomCategory(document.getCustomCategory());
        model.addAttribute("document", document);
        model.addAttribute("documentUpdateRequest", request);
        model.addAttribute("categoryOptions", documentService.getAvailableCategories(user));
        return "document/edit";
    }

    @PostMapping("/{id}/edit")
    public String updateMetadata(@AuthenticationPrincipal CustomUserDetails principal,
                                 @PathVariable Long id,
                                 @ModelAttribute DocumentUpdateRequest request,
                                 RedirectAttributes redirectAttributes) {
        User user = currentUser(principal);
        documentService.updateMetadata(id, user, request);
        redirectAttributes.addFlashAttribute("successMessage", "Document details updated.");
        return "redirect:/documents/" + id + "/manage";
    }

    @PostMapping("/merge-pdf")
    public String mergePdfs(@AuthenticationPrincipal CustomUserDetails principal,
                            @ModelAttribute MergePdfRequest request,
                            RedirectAttributes redirectAttributes) {
        User user = currentUser(principal);
        try {
            documentService.mergePdfDocuments(user, request);
            redirectAttributes.addFlashAttribute("successMessage", "PDF documents merged successfully.");
        } catch (IllegalArgumentException exception) {
            redirectAttributes.addFlashAttribute("errorMessage", exception.getMessage());
        }
        return "redirect:/documents/tools/merge";
    }

    @PostMapping("/{id}/convert-to-pdf")
    public String convertImageToPdf(@AuthenticationPrincipal CustomUserDetails principal,
                                    @PathVariable Long id,
                                    @RequestParam(value = "title", required = false) String title,
                                    @RequestParam(value = "signerName", required = false) String signerName,
                                    RedirectAttributes redirectAttributes) {
        User user = currentUser(principal);
        try {
            Document document = documentService.getAccessibleDocument(id, user);
            if (isPowerPointDocument(document)) {
                documentService.convertPresentationToPdf(id, user, title);
                redirectAttributes.addFlashAttribute("successMessage", "PowerPoint converted to PDF and saved in your vault.");
            } else {
                documentService.convertImageToPdf(id, user, title, signerName);
                redirectAttributes.addFlashAttribute("successMessage", "Document converted to PDF and saved in your vault.");
            }
        } catch (IllegalArgumentException exception) {
            redirectAttributes.addFlashAttribute("errorMessage", exception.getMessage());
        }
        return "redirect:/documents/" + id + "/manage";
    }

    @PostMapping("/{id}/convert-to-docx")
    public String convertPdfToDocx(@AuthenticationPrincipal CustomUserDetails principal,
                                   @PathVariable Long id,
                                   @RequestParam(value = "title", required = false) String title,
                                    RedirectAttributes redirectAttributes) {
        User user = currentUser(principal);
        try {
            documentService.convertPdfToDocxDocument(id, user, title);
            redirectAttributes.addFlashAttribute("successMessage", "PDF converted to a DOCX document and saved in your vault.");
        } catch (IllegalArgumentException exception) {
            redirectAttributes.addFlashAttribute("errorMessage", exception.getMessage());
        }
        return "redirect:/documents/" + id + "/manage";
    }

    @PostMapping("/{id}/convert-to-text")
    public String convertPdfToText(@AuthenticationPrincipal CustomUserDetails principal,
                                   @PathVariable Long id,
                                   @RequestParam(value = "title", required = false) String title,
                                    RedirectAttributes redirectAttributes) {
        User user = currentUser(principal);
        try {
            documentService.convertPdfToTextDocument(id, user, title);
            redirectAttributes.addFlashAttribute("successMessage", "PDF converted to a text document and saved in your vault.");
        } catch (IllegalArgumentException exception) {
            redirectAttributes.addFlashAttribute("errorMessage", exception.getMessage());
        }
        return "redirect:/documents/" + id + "/manage";
    }

    @PostMapping("/{id}/split-pdf")
    public String splitPdf(@AuthenticationPrincipal CustomUserDetails principal,
                           @PathVariable Long id,
                           RedirectAttributes redirectAttributes) {
        User user = currentUser(principal);
        int createdPages = documentService.splitPdfDocument(id, user).size();
        redirectAttributes.addFlashAttribute("successMessage", "PDF split into " + createdPages + " separate documents.");
        return "redirect:/documents/" + id + "/manage";
    }

    @PostMapping("/{id}/split-pdf-range")
    public String splitPdfRange(@AuthenticationPrincipal CustomUserDetails principal,
                                @PathVariable Long id,
                                @RequestParam("startPage") int startPage,
                                @RequestParam("endPage") int endPage,
                                @RequestParam(value = "title", required = false) String title,
                                RedirectAttributes redirectAttributes) {
        User user = currentUser(principal);
        documentService.splitPdfDocument(id, user, startPage, endPage, title);
        redirectAttributes.addFlashAttribute("successMessage", "PDF pages " + startPage + " to " + endPage + " were saved as a new document.");
        return "redirect:/documents/" + id + "/manage";
    }

    @PostMapping("/{id}/split-pdf-pages")
    public String splitPdfPages(@AuthenticationPrincipal CustomUserDetails principal,
                                @PathVariable Long id,
                                @RequestParam("pageSelection") String pageSelection,
                                @RequestParam(value = "title", required = false) String title,
                                RedirectAttributes redirectAttributes) {
        User user = currentUser(principal);
        Document selectedDocument = documentService.splitPdfDocument(id, user, pageSelection, title);
        redirectAttributes.addFlashAttribute("successMessage", "Selected PDF pages were saved as " + selectedDocument.getTitle() + ".");
        return "redirect:/documents/" + id + "/manage";
    }

    @PostMapping("/{id}/version")
    public String uploadVersion(@AuthenticationPrincipal CustomUserDetails principal,
                                @PathVariable Long id,
                                @RequestParam("file") MultipartFile file,
                                RedirectAttributes redirectAttributes) {
        User user = currentUser(principal);
        documentService.updateVersion(id, user, file);
        redirectAttributes.addFlashAttribute("successMessage", "New document version uploaded.");
        return "redirect:/documents/" + id + "/manage";
    }

    @GetMapping("/{id}/download")
    public ResponseEntity<byte[]> download(@AuthenticationPrincipal CustomUserDetails principal,
                                           @PathVariable Long id) {
        User user = currentUser(principal);
        Document document = documentService.getAccessibleDocument(id, user);
        byte[] content = documentService.download(id, user);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + safeFileName(document) + "\"")
                .contentType(octetStreamContentType())
                .body(content);
    }

    @GetMapping("/{id}/view")
    public ResponseEntity<byte[]> view(@AuthenticationPrincipal CustomUserDetails principal,
                                       @PathVariable Long id) {
        User user = currentUser(principal);
        Document document = documentService.getAccessibleDocument(id, user);
        byte[] content = documentService.download(id, user);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + safeFileName(document) + "\"")
                .contentType(nonNullContentType(document))
                .body(content);
    }

    @GetMapping("/{id}/preview")
    public String preview(@AuthenticationPrincipal CustomUserDetails principal,
                          @PathVariable Long id,
                          Model model) {
        User user = currentUser(principal);
        Document document = documentService.getAccessibleDocument(id, user);
        String contentType = document.getContentType() == null ? "" : document.getContentType().toLowerCase();
        boolean previewable = contentType.startsWith("image/")
                || contentType.equals("application/pdf")
                || contentType.startsWith("text/");
        model.addAttribute("document", document);
        model.addAttribute("previewable", previewable);
        model.addAttribute("contentType", contentType);
        return "document/preview";
    }

    @GetMapping("/public/{qrToken}")
    public ResponseEntity<byte[]> publicDownload(@PathVariable String qrToken) {
        Document document = documentService.getByQrToken(qrToken);
        byte[] content = documentService.downloadByQrToken(qrToken);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + safeFileName(document) + "\"")
                .contentType(octetStreamContentType())
                .body(content);
    }

    @GetMapping("/public/{qrToken}/view")
    public ResponseEntity<byte[]> publicView(@PathVariable String qrToken) {
        Document document = documentService.getByQrToken(qrToken);
        byte[] content = documentService.downloadByQrToken(qrToken);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + safeFileName(document) + "\"")
                .contentType(nonNullContentType(document))
                .body(content);
    }

    @PostMapping("/{id}/delete")
    public String delete(@AuthenticationPrincipal CustomUserDetails principal,
                         @PathVariable Long id,
                         RedirectAttributes redirectAttributes) {
        User user = currentUser(principal);
        documentService.deleteDocument(id, user);
        redirectAttributes.addFlashAttribute("successMessage", "Document moved to recycle bin.");
        return "redirect:/documents";
    }

    @PostMapping("/{id}/delete/permanent")
    public String permanentDelete(@AuthenticationPrincipal CustomUserDetails principal,
                                  @PathVariable Long id,
                                  RedirectAttributes redirectAttributes) {
        User user = currentUser(principal);
        documentService.permanentlyDeleteDocument(id, user);
        redirectAttributes.addFlashAttribute("successMessage", "Document permanently deleted.");
        return "redirect:/documents";
    }

    @GetMapping("/{id}/delete")
    public String deletePage(@AuthenticationPrincipal CustomUserDetails principal,
                             @PathVariable Long id,
                             Model model) {
        User user = currentUser(principal);
        model.addAttribute("document", documentService.getAccessibleDocument(id, user));
        return "document/delete";
    }

    @PostMapping("/{id}/restore")
    public String restore(@AuthenticationPrincipal CustomUserDetails principal,
                          @PathVariable Long id,
                          RedirectAttributes redirectAttributes) {
        User user = currentUser(principal);
        documentService.restoreDocument(id, user);
        redirectAttributes.addFlashAttribute("successMessage", "Document restored.");
        return "redirect:/documents";
    }

    @PostMapping("/{id}/share")
    public String share(@AuthenticationPrincipal CustomUserDetails principal,
                        @PathVariable Long id,
                        @RequestParam("recipientEmail") String recipientEmail,
                        @RequestParam(value = "permission", defaultValue = "VIEW") String permission,
                        RedirectAttributes redirectAttributes) {
        User user = currentUser(principal);
        try {
            ShareDocumentRequest request = new ShareDocumentRequest();
            request.setRecipientEmail(recipientEmail == null ? "" : recipientEmail.trim());
            request.setPermission(com.vaultx.enums.SharePermission.valueOf(permission));
            documentService.shareDocument(id, user, request);
            redirectAttributes.addFlashAttribute("successMessage", "Document shared successfully.");
        } catch (IllegalArgumentException exception) {
            redirectAttributes.addFlashAttribute("errorMessage", exception.getMessage());
        }
        return "redirect:/documents/" + id + "/manage";
    }

    @GetMapping("/{id}/share")
    public String sharePage(@AuthenticationPrincipal CustomUserDetails principal,
                            @PathVariable Long id,
                            Model model) {
        User user = currentUser(principal);
        model.addAttribute("document", documentService.getAccessibleDocument(id, user));
        return "document/share";
    }

    @GetMapping("/{id}/version")
    public String versionPage(@AuthenticationPrincipal CustomUserDetails principal,
                              @PathVariable Long id,
                              Model model) {
        User user = currentUser(principal);
        Document document = documentService.getAccessibleDocument(id, user);
        model.addAttribute("document", document);
        model.addAttribute("versions", documentService.getVersions(id, user));
        return "document/version";
    }

    @GetMapping("/{id}/convert")
    public String convertDocumentPage(@AuthenticationPrincipal CustomUserDetails principal,
                                      @PathVariable Long id,
                                      Model model) {
        User user = currentUser(principal);
        model.addAttribute("document", documentService.getAccessibleDocument(id, user));
        return "document/convert-single";
    }

    @GetMapping("/{id}/split")
    public String splitDocumentPage(@AuthenticationPrincipal CustomUserDetails principal,
                                    @PathVariable Long id,
                                    Model model) {
        User user = currentUser(principal);
        Document document = documentService.getAccessibleDocument(id, user);
        model.addAttribute("document", document);
        model.addAttribute("pageCount", documentService.getPdfPageCount(id, user));
        return "document/split-single";
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(IllegalArgumentException.class)
    public String handleIllegalArgumentException(IllegalArgumentException exception,
                                                 RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("errorMessage", exception.getMessage());
        return "redirect:/documents";
    }

    @GetMapping("/search")
    public String search(@AuthenticationPrincipal CustomUserDetails principal,
                         @RequestParam("keyword") String keyword,
                         Model model) {
        return "redirect:/documents/search-page?keyword=" + keyword;
    }

    private MediaType resolveContentType(Document document) {
        try {
            String contentType = document.getContentType();
            if (contentType != null && !contentType.isBlank()) {
                return MediaType.parseMediaType(contentType);
            }
        } catch (Exception ignored) {
        }
        return MediaTypeFactory.getMediaType(safeFileName(document))
                .orElse(MediaType.APPLICATION_OCTET_STREAM);
    }

    private MediaType nonNullContentType(Document document) {
        return Objects.requireNonNull(resolveContentType(document), "contentType");
    }

    private MediaType octetStreamContentType() {
        return Objects.requireNonNull(MediaType.APPLICATION_OCTET_STREAM, "contentType");
    }

    private String safeFileName(Document document) {
        String originalFileName = document.getOriginalFileName();
        if (originalFileName == null || originalFileName.isBlank()) {
            return "document";
        }
        return originalFileName;
    }

    private void populateDocumentModel(Model model, User user, String sortBy, String category) {
        List<Document> allDocuments = documentService.getMyDocuments(user, "dateDesc", "ALL");
        model.addAttribute("categoryFolders", buildCategoryFolders(allDocuments));
        model.addAttribute("sharedDocuments", documentService.getSharedWithMe(user));
        model.addAttribute("recycleBin", documentService.getRecycleBin(user));
        model.addAttribute("documentUploadRequest", new DocumentUploadRequest());
        model.addAttribute("mergePdfRequest", new MergePdfRequest());
        model.addAttribute("categoryOptions", documentService.getAvailableCategories(user));
        model.addAttribute("selectedSort", sortBy);
        model.addAttribute("selectedCategory", category);
        model.addAttribute("shareDocumentRequest", new ShareDocumentRequest());
    }

    private void applyPaging(Model model, List<Document> documents, int page) {
        int safePage = Math.max(page, 0);
        int totalDocuments = documents.size();
        int totalPages = totalDocuments == 0 ? 0 : (int) Math.ceil(totalDocuments / (double) USER_PAGE_SIZE);
        int currentPage = totalPages == 0 ? 0 : Math.min(safePage, totalPages - 1);
        int fromIndex = Math.min(currentPage * USER_PAGE_SIZE, totalDocuments);
        int toIndex = Math.min(fromIndex + USER_PAGE_SIZE, totalDocuments);
        List<Document> pageContent = documents.subList(fromIndex, toIndex);
        Page<Document> documentPage = new org.springframework.data.domain.PageImpl<>(pageContent, org.springframework.data.domain.PageRequest.of(currentPage, USER_PAGE_SIZE), totalDocuments);
        model.addAttribute("documentsPage", documentPage);
        model.addAttribute("documents", pageContent);
        model.addAttribute("currentPage", currentPage);
        model.addAttribute("totalPages", totalPages);
        model.addAttribute("pageSize", USER_PAGE_SIZE);
        model.addAttribute("totalDocuments", totalDocuments);
    }

    private void applySharedPaging(Model model, List<SharedDocument> sharedDocuments, int page) {
        int safePage = Math.max(page, 0);
        int totalShares = sharedDocuments.size();
        int totalPages = totalShares == 0 ? 0 : (int) Math.ceil(totalShares / (double) SHARED_PAGE_SIZE);
        int currentPage = totalPages == 0 ? 0 : Math.min(safePage, totalPages - 1);
        int fromIndex = Math.min(currentPage * SHARED_PAGE_SIZE, totalShares);
        int toIndex = Math.min(fromIndex + SHARED_PAGE_SIZE, totalShares);
        List<SharedDocument> pageContent = sharedDocuments.subList(fromIndex, toIndex);
        Page<SharedDocument> sharedPage = new org.springframework.data.domain.PageImpl<>(
                pageContent,
                org.springframework.data.domain.PageRequest.of(currentPage, SHARED_PAGE_SIZE),
                totalShares
        );
        model.addAttribute("sharedDocumentsPage", sharedPage);
        model.addAttribute("sharedDocuments", pageContent);
        model.addAttribute("currentPage", currentPage);
        model.addAttribute("totalPages", totalPages);
        model.addAttribute("pageSize", SHARED_PAGE_SIZE);
    }

    private User currentUser(CustomUserDetails principal) {
        return userService.getById(principal.getId());
    }

    private List<DocumentCategoryFolder> buildCategoryFolders(List<Document> documents) {
        Map<String, List<Document>> groupedDocuments = new LinkedHashMap<>();
        for (Document document : documents) {
            String folderKey = resolveFolderKey(document);
            groupedDocuments.computeIfAbsent(folderKey, key -> new ArrayList<>()).add(document);
        }
        return groupedDocuments.entrySet().stream()
                .map(entry -> {
                    DocumentCategoryFolder folder = new DocumentCategoryFolder();
                    folder.setFolderKey(entry.getKey());
                    folder.setFilterValue(entry.getKey());
                    folder.setFolderName(resolveFolderDisplayName(entry.getKey()));
                    folder.setIconLabel(resolveFolderIcon(entry.getKey()));
                    folder.setAccentClass(resolveFolderAccent(entry.getKey()));
                    folder.setDocuments(entry.getValue());
                    return folder;
                })
                .sorted(Comparator.comparingInt((DocumentCategoryFolder folder) -> folderSortOrder(folder.getFolderKey()))
                        .thenComparing(DocumentCategoryFolder::getFolderName, String.CASE_INSENSITIVE_ORDER))
                .toList();
    }

    private String resolveFolderKey(Document document) {
        if (document.getCustomCategory() != null && !document.getCustomCategory().isBlank()) {
            return document.getCustomCategory().trim();
        }
        return document.getCategory() == null ? DocumentCategory.OTHER.name() : document.getCategory().name();
    }

    private String resolveFolderDisplayName(String folderKey) {
        try {
            DocumentCategory category = DocumentCategory.valueOf(folderKey.toUpperCase(Locale.ENGLISH));
            return switch (category) {
                case AADHAR -> "Aadhar";
                case PAN -> "PAN";
                case MARKS_CARD -> "Marks Card";
                case CERTIFICATE -> "Certificate";
                case PASSPORT -> "Passport";
                case LICENSE -> "License";
                case INSURANCE -> "Insurance";
                case BANK -> "Bank";
                case NOTES -> "Notes";
                case BILLS -> "Bills";
                case TAX -> "Tax";
                case MEDICAL -> "Medical";
                case PROPERTY -> "Property";
                case EDUCATION -> "Education";
                case WORK -> "Work";
                case RECEIPT -> "Receipt";
                case OTHER -> "Other";
            };
        } catch (Exception ignored) {
            return toTitleCase(folderKey);
        }
    }

    private String resolveFolderIcon(String folderKey) {
        String normalized = folderKey.toUpperCase(Locale.ENGLISH);
        return switch (normalized) {
            case "AADHAR" -> "ID";
            case "PAN" -> "PN";
            case "MARKS_CARD" -> "MC";
            case "CERTIFICATE" -> "CE";
            case "PASSPORT" -> "PP";
            case "LICENSE" -> "LC";
            case "INSURANCE" -> "IN";
            case "BANK" -> "BK";
            case "NOTES" -> "NT";
            case "BILLS" -> "BL";
            case "TAX" -> "TX";
            case "MEDICAL" -> "MD";
            case "PROPERTY" -> "PR";
            case "EDUCATION" -> "ED";
            case "WORK" -> "WK";
            case "RECEIPT" -> "RC";
            default -> initials(folderKey);
        };
    }

    private String resolveFolderAccent(String folderKey) {
        String normalized = folderKey.toUpperCase(Locale.ENGLISH);
        return switch (normalized) {
            case "AADHAR", "PAN", "LICENSE" -> "vaultx-folder--blue";
            case "MARKS_CARD", "EDUCATION", "WORK" -> "vaultx-folder--violet";
            case "CERTIFICATE", "RECEIPT", "TAX" -> "vaultx-folder--amber";
            case "PASSPORT", "INSURANCE", "MEDICAL" -> "vaultx-folder--green";
            case "BANK", "PROPERTY" -> "vaultx-folder--teal";
            case "NOTES", "OTHER" -> "vaultx-folder--pink";
            default -> {
                int bucket = Math.abs(folderKey.hashCode()) % 3;
                yield switch (bucket) {
                    case 0 -> "vaultx-folder--blue";
                    case 1 -> "vaultx-folder--green";
                    default -> "vaultx-folder--pink";
                };
            }
        };
    }

    private int folderSortOrder(String folderKey) {
        try {
            return switch (DocumentCategory.valueOf(folderKey.toUpperCase(Locale.ENGLISH))) {
                case AADHAR -> 10;
                case PAN -> 20;
                case MARKS_CARD -> 30;
                case CERTIFICATE -> 40;
                case PASSPORT -> 50;
                case LICENSE -> 60;
                case INSURANCE -> 70;
                case BANK -> 80;
                case NOTES -> 90;
                case BILLS -> 100;
                case TAX -> 110;
                case MEDICAL -> 120;
                case PROPERTY -> 130;
                case EDUCATION -> 140;
                case WORK -> 150;
                case RECEIPT -> 160;
                case OTHER -> 900;
            };
        } catch (Exception ignored) {
            return 500;
        }
    }

    private String toTitleCase(String value) {
        if (value == null || value.isBlank()) {
            return "Other";
        }
        String[] parts = value.trim().replaceAll("[_]+", " ").split("\\s+");
        StringBuilder builder = new StringBuilder();
        for (String part : parts) {
            if (part.isBlank()) {
                continue;
            }
            if (builder.length() > 0) {
                builder.append(' ');
            }
            builder.append(Character.toUpperCase(part.charAt(0)));
            if (part.length() > 1) {
                builder.append(part.substring(1).toLowerCase(Locale.ENGLISH));
            }
        }
        return builder.toString();
    }

    private String initials(String value) {
        if (value == null || value.isBlank()) {
            return "CU";
        }
        String[] parts = value.trim().replaceAll("[_]+", " ").split("\\s+");
        StringBuilder builder = new StringBuilder();
        for (String part : parts) {
            if (part.isBlank()) {
                continue;
            }
            builder.append(Character.toUpperCase(part.charAt(0)));
            if (builder.length() == 2) {
                break;
            }
        }
        while (builder.length() < 2) {
            builder.append('X');
        }
        return builder.toString();
    }

    private boolean isPowerPointDocument(Document document) {
        String contentType = document.getContentType() == null ? "" : document.getContentType().toLowerCase();
        String fileName = document.getOriginalFileName() == null ? "" : document.getOriginalFileName().toLowerCase();
        return contentType.equals("application/vnd.ms-powerpoint")
                || contentType.equals("application/vnd.openxmlformats-officedocument.presentationml.presentation")
                || fileName.endsWith(".ppt")
                || fileName.endsWith(".pptx");
    }
}
