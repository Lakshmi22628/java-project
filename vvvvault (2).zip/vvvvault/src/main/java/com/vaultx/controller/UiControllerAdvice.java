package com.vaultx.controller;

import com.vaultx.entity.User;
import com.vaultx.security.CustomUserDetails;
import com.vaultx.service.UserService;
import java.util.Base64;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
@RequiredArgsConstructor
public class UiControllerAdvice {

    private final UserService userService;

    @ModelAttribute("currentUser")
    public User currentUser(@AuthenticationPrincipal CustomUserDetails principal) {
        if (principal == null) {
            return null;
        }
        return userService.getById(principal.getId());
    }

    @ModelAttribute("currentUserAvatarDataUri")
    public String currentUserAvatarDataUri(@ModelAttribute("currentUser") User currentUser) {
        if (currentUser == null || currentUser.getProfilePicture() == null || currentUser.getProfilePicture().length == 0) {
            return null;
        }
        String contentType = currentUser.getProfilePictureContentType();
        if (contentType == null || contentType.isBlank()) {
            contentType = "image/png";
        }
        return "data:" + contentType + ";base64," + Base64.getEncoder().encodeToString(currentUser.getProfilePicture());
    }
}
