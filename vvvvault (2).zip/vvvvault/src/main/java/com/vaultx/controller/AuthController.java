package com.vaultx.controller;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.vaultx.dto.ForgotPasswordRequest;
import com.vaultx.dto.LoginRequest;
import com.vaultx.dto.OtpRequest;
import com.vaultx.dto.RegistrationRequest;
import com.vaultx.dto.ResetPasswordRequest;
import com.vaultx.entity.User;
import com.vaultx.enums.OtpPurpose;
import com.vaultx.enums.OtpValidationResult;
import com.vaultx.enums.Role;
import com.vaultx.security.CustomUserDetails;
import com.vaultx.security.CustomUserDetailsService;
import com.vaultx.service.AuditService;
import com.vaultx.service.OtpService;
import com.vaultx.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class AuthController {

    private static final String PENDING_LOGIN_EMAIL = "pendingLoginEmail";
    private static final String PENDING_RESET_EMAIL = "pendingResetEmail";
    private static final String WRONG_OTP_MESSAGE = "Wrong OTP entered. Please enter the correct OTP.";

    private final UserService userService;
    private final OtpService otpService;
    private final PasswordEncoder passwordEncoder;
    private final CustomUserDetailsService userDetailsService;
    private final AuditService auditService;

    private boolean isAdmin(User user) {
        return user != null && Role.ROLE_ADMIN.equals(user.getRole());
    }

    @GetMapping("/login")
    public String loginPage(Model model) {
        if (!model.containsAttribute("loginRequest")) {
            model.addAttribute("loginRequest", new LoginRequest());
        }
        return "auth/login";
    }

    @GetMapping("/admin/login")
    public String adminLoginPage(Model model) {
        if (!model.containsAttribute("loginRequest")) {
            model.addAttribute("loginRequest", new LoginRequest());
        }
        return "auth/admin-login";
    }

    @PostMapping("/admin/login")
    public String adminLogin(@Valid @ModelAttribute LoginRequest loginRequest,
                             BindingResult bindingResult,
                             HttpSession session,
                             HttpServletRequest request,
                             RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "auth/admin-login";
        }
        try {
            User user = userService.getByEmail(loginRequest.getEmail());
            if (!isAdmin(user)) {
                bindingResult.rejectValue("email", "email.notAdmin", "Admin access is required to sign in here.");
                return "auth/admin-login";
            }
            if (!passwordEncoder.matches(loginRequest.getPassword(), user.getPassword())) {
                bindingResult.reject("password.invalid", "Invalid email or password");
                return "auth/admin-login";
            }
            otpService.generateAndSendOtp(user, OtpPurpose.LOGIN);
            session.setAttribute(PENDING_LOGIN_EMAIL, user.getEmail());
            auditService.log(user, "OTP_SENT", "OTP sent for admin login", request.getRemoteAddr());
            redirectAttributes.addFlashAttribute("successMessage", "OTP sent to your email.");
            return "redirect:/verify-otp";
        } catch (IllegalStateException exception) {
            redirectAttributes.addFlashAttribute("errorMessage", exception.getMessage());
            return "redirect:/admin/login";
        } catch (IllegalArgumentException exception) {
            bindingResult.rejectValue("email", "email.notFound", "No admin account found for this email. Contact the system administrator.");
            return "auth/admin-login";
        }
    }

    @GetMapping("/register")
    public String registerPage(Model model) {
        if (!model.containsAttribute("registrationRequest")) {
            model.addAttribute("registrationRequest", new RegistrationRequest());
        }
        return "auth/register";
    }

    @GetMapping("/verify-otp")
    public String verifyOtpPage(Model model) {
        if (!model.containsAttribute("otpRequest")) {
            model.addAttribute("otpRequest", new OtpRequest());
        }
        return "auth/verify-otp";
    }

    @GetMapping("/forgot-password")
    public String forgotPasswordPage(Model model) {
        if (!model.containsAttribute("forgotPasswordRequest")) {
            model.addAttribute("forgotPasswordRequest", new ForgotPasswordRequest());
        }
        return "auth/forgot-password";
    }

    @GetMapping("/reset-password")
    public String resetPasswordPage(HttpSession session,
                                    Model model,
                                    RedirectAttributes redirectAttributes) {
        Object pendingResetEmail = session.getAttribute(PENDING_RESET_EMAIL);
        String email = pendingResetEmail instanceof String value ? value : null;
        if (email == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Start with Forgot Password to receive a reset OTP.");
            return "redirect:/forgot-password";
        }
        if (!model.containsAttribute("resetPasswordRequest")) {
            model.addAttribute("resetPasswordRequest", new ResetPasswordRequest());
        }
        model.addAttribute("resetEmail", email);
        return "auth/reset-password";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute RegistrationRequest registrationRequest,
                           BindingResult bindingResult,
                           RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "auth/register";
        }
        try {
            userService.register(registrationRequest);
            redirectAttributes.addFlashAttribute("successMessage", "Registration successful. Please log in.");
            return "redirect:/login";
        } catch (IllegalArgumentException exception) {
            bindingResult.rejectValue("email", "email.exists", exception.getMessage());
            return "auth/register";
        }
    }

    @PostMapping("/login")
    public String login(@Valid @ModelAttribute LoginRequest loginRequest,
                        BindingResult bindingResult,
                        HttpSession session,
                        HttpServletRequest request,
                        RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "auth/login";
        }
        try {
            User user = userService.getByEmail(loginRequest.getEmail());
            if (!passwordEncoder.matches(loginRequest.getPassword(), user.getPassword())) {
                bindingResult.reject("password.invalid", "Invalid email or password");
                return "auth/login";
            }
            otpService.generateAndSendOtp(user, OtpPurpose.LOGIN);
            session.setAttribute(PENDING_LOGIN_EMAIL, user.getEmail());
            auditService.log(user, "OTP_SENT", "OTP sent for login", request.getRemoteAddr());
            redirectAttributes.addFlashAttribute("successMessage", "OTP sent to your email.");
            return "redirect:/verify-otp";
        } catch (IllegalStateException exception) {
            redirectAttributes.addFlashAttribute("errorMessage", exception.getMessage());
            return "redirect:/login";
        } catch (IllegalArgumentException exception) {
            bindingResult.rejectValue("email", "email.notFound", "No account found for this email. Don't have an account? Create one.");
            return "auth/login";
        }
    }

    @PostMapping("/forgot-password")
    public String forgotPassword(@Valid @ModelAttribute ForgotPasswordRequest forgotPasswordRequest,
                                 BindingResult bindingResult,
                                 HttpSession session,
                                 HttpServletRequest request,
                                 RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "auth/forgot-password";
        }
        try {
            User user = userService.getByEmail(forgotPasswordRequest.getEmail());
            otpService.generateAndSendOtp(user, OtpPurpose.PASSWORD_RESET);
            session.setAttribute(PENDING_RESET_EMAIL, user.getEmail());
            auditService.log(user, "PASSWORD_RESET_OTP_SENT", "Password reset OTP sent", request.getRemoteAddr());
            redirectAttributes.addFlashAttribute("successMessage", "Password reset OTP sent to your email.");
            return "redirect:/reset-password";
        } catch (IllegalStateException exception) {
            redirectAttributes.addFlashAttribute("errorMessage", exception.getMessage());
            return "redirect:/forgot-password";
        } catch (IllegalArgumentException exception) {
            bindingResult.rejectValue("email", "email.notFound", "No account found for this email. Don't have an account? Create one.");
            return "auth/forgot-password";
        }
    }

    @PostMapping("/verify-otp")
    public String verifyOtp(@Valid @ModelAttribute OtpRequest otpRequest,
                            BindingResult bindingResult,
                            HttpSession session,
                            HttpServletRequest request,
                            RedirectAttributes redirectAttributes) {
        Object pendingLoginEmail = session.getAttribute(PENDING_LOGIN_EMAIL);
        String email = pendingLoginEmail instanceof String value ? value : null;
        if (email == null) {
            bindingResult.reject("otp.session", "Login session expired. Please login again.");
            return "auth/verify-otp";
        }
        try {
            User user = userService.getByEmail(email);
            OtpValidationResult validationResult = otpService.validateOtp(user, otpRequest.getOtp(), OtpPurpose.LOGIN);
            if (validationResult != OtpValidationResult.VALID) {
                if (validationResult == OtpValidationResult.EXPIRED) {
                    bindingResult.reject("otp.expired", "OTP expired. Please regenerate OTP by logging in again.");
                } else {
                    bindingResult.reject("otp.invalid", WRONG_OTP_MESSAGE);
                }
                return "auth/verify-otp";
            }
            CustomUserDetails userDetails = (CustomUserDetails) userDetailsService.loadUserByUsername(user.getEmail());
            Authentication authentication = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
            SecurityContext context = SecurityContextHolder.createEmptyContext();
            context.setAuthentication(authentication);
            SecurityContextHolder.setContext(context);
            session.setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, context);
            session.removeAttribute(PENDING_LOGIN_EMAIL);
            auditService.log(user, "LOGIN_SUCCESS", "User logged in with OTP 2FA", request.getRemoteAddr());
            return isAdmin(user) ? "redirect:/admin/dashboard" : "redirect:/";
        } catch (IllegalArgumentException exception) {
            redirectAttributes.addFlashAttribute("errorMessage", exception.getMessage());
            return "redirect:/login";
        }
    }

    @PostMapping("/reset-password")
    public String resetPassword(@Valid @ModelAttribute ResetPasswordRequest resetPasswordRequest,
                                BindingResult bindingResult,
                                HttpSession session,
                                HttpServletRequest request,
                                Model model,
                                RedirectAttributes redirectAttributes) {
        Object pendingResetEmail = session.getAttribute(PENDING_RESET_EMAIL);
        String email = pendingResetEmail instanceof String value ? value : null;
        if (email == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Your password reset session expired. Please try again.");
            return "redirect:/forgot-password";
        }
        model.addAttribute("resetEmail", email);
        if (!resetPasswordRequest.getPassword().equals(resetPasswordRequest.getConfirmPassword())) {
            bindingResult.rejectValue("confirmPassword", "password.mismatch", "Password and confirm password must match.");
        }
        if (bindingResult.hasErrors()) {
            return "auth/reset-password";
        }
        try {
            User user = userService.getByEmail(email);
            OtpValidationResult validationResult = otpService.validateOtp(user, resetPasswordRequest.getOtp(), OtpPurpose.PASSWORD_RESET);
            if (validationResult != OtpValidationResult.VALID) {
                if (validationResult == OtpValidationResult.EXPIRED) {
                    bindingResult.rejectValue("otp", "otp.expired", "OTP expired. Please regenerate OTP.");
                } else {
                    bindingResult.rejectValue("otp", "otp.invalid", WRONG_OTP_MESSAGE);
                }
                return "auth/reset-password";
            }
            userService.updatePassword(email, resetPasswordRequest.getPassword());
            session.removeAttribute(PENDING_RESET_EMAIL);
            auditService.log(user, "PASSWORD_RESET_SUCCESS", "Password was reset", request.getRemoteAddr());
            redirectAttributes.addFlashAttribute("successMessage", "Password reset successful. Please login with your new password.");
            return "redirect:/login";
        } catch (IllegalArgumentException exception) {
            String message = exception.getMessage() == null ? "Password reset failed." : exception.getMessage();
            bindingResult.reject("reset.invalid", message);
            return "auth/reset-password";
        }
    }
}
