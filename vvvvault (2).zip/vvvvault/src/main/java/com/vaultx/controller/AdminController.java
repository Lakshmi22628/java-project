package com.vaultx.controller;

import com.vaultx.entity.Document;
import com.vaultx.entity.AuditLog;
import com.vaultx.entity.User;
import com.vaultx.enums.Role;
import com.vaultx.service.AdminService;
import com.vaultx.service.AuditService;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {

    private static final String PRIMARY_ADMIN_EMAIL = "vaultx89@gmail.com";
    private static final String FLASH_SUCCESS_MESSAGE = "successMessage";
    private static final String FLASH_ERROR_MESSAGE = "errorMessage";
    private static final int ADMIN_PAGE_SIZE = 15;

    private final AdminService adminService;
    private final AuditService auditService;

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        List<User> users = adminService.getAllUsers();
        List<Document> documents = adminService.getAllDocuments();
        List<String> securityAlerts = adminService.getSecurityAlerts();
        List<?> recentLogs = auditService.getRecentLogs();

        long totalUsers = users.size();
        long activeUsers = users.stream().filter(User::isAccountNonLocked).count();
        long lockedUsers = totalUsers - activeUsers;
        long totalDocuments = documents.size();
        long liveDocuments = documents.stream().filter(document -> !document.isDeleted()).count();
        long archivedDocuments = totalDocuments - liveDocuments;
        long encryptedDocuments = documents.stream().filter(Document::isEncrypted).count();
        long failedLoginAttempts = adminService.getFailedLoginAttempts();
        long storageUsed = adminService.getStorageUsed();

        model.addAttribute("totalUsers", totalUsers);
        model.addAttribute("activeUsers", activeUsers);
        model.addAttribute("lockedUsers", lockedUsers);
        model.addAttribute("totalDocuments", totalDocuments);
        model.addAttribute("liveDocuments", liveDocuments);
        model.addAttribute("archivedDocuments", archivedDocuments);
        model.addAttribute("encryptedDocuments", encryptedDocuments);
        model.addAttribute("storageUsed", storageUsed);
        model.addAttribute("storageUsedFormatted", formatStorage(storageUsed));
        model.addAttribute("failedLoginAttempts", failedLoginAttempts);
        model.addAttribute("securityAlerts", securityAlerts);
        model.addAttribute("securityAlertsCount", securityAlerts.size());
        model.addAttribute("users", users);
        model.addAttribute("documents", documents);
        model.addAttribute("logs", recentLogs);
        model.addAttribute("recentActivityCount", recentLogs.size());
        model.addAttribute("reports", adminService.getStorageReports());
        model.addAttribute("primaryAdminEmail", PRIMARY_ADMIN_EMAIL);
        model.addAttribute("userAccessPercent", percentage(activeUsers, totalUsers));
        model.addAttribute("encryptedCoveragePercent", percentage(encryptedDocuments, totalDocuments));
        model.addAttribute("liveDocumentPercent", percentage(liveDocuments, totalDocuments));
        model.addAttribute("alertPressurePercent", Math.min(100L, failedLoginAttempts * 10L));
        return "admin/dashboard";
    }

    @PostMapping("/users/{id}/toggle-lock")
    public String toggleUserLock(@PathVariable Long id, @RequestParam(defaultValue = "/admin/dashboard") String redirectUrl, RedirectAttributes redirectAttributes) {
        try {
            adminService.toggleUserLock(id);
            addSuccessMessage(redirectAttributes, "User access updated successfully.");
        } catch (IllegalArgumentException exception) {
            addErrorMessage(redirectAttributes, exception.getMessage());
        }
        return "redirect:" + redirectUrl;
    }

    @PostMapping("/reports/refresh")
    public String refreshStorageReport(RedirectAttributes redirectAttributes) {
        adminService.refreshStorageReport();
        addSuccessMessage(redirectAttributes, "Storage report refreshed.");
        return "redirect:/admin/dashboard";
    }

    @GetMapping("/users")
    public String userManagement(@RequestParam(required = false) String query, Model model) {
        List<User> users = query != null && !query.isEmpty() ? adminService.searchUsers(query) : adminService.getAllUsers();
        model.addAttribute("users", users);
        model.addAttribute("query", query);
        return "admin/user-management";
    }

    @PostMapping("/users/{id}/change-role")
    public String changeUserRole(@PathVariable Long id, @RequestParam Role role, RedirectAttributes redirectAttributes) {
        try {
            adminService.changeUserRole(id, role);
            addSuccessMessage(redirectAttributes, "User role updated successfully.");
        } catch (IllegalArgumentException exception) {
            addErrorMessage(redirectAttributes, exception.getMessage());
        }
        return "redirect:/admin/users";
    }

    @PostMapping("/users/{id}/delete")
    public String deleteUser(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            adminService.deleteUser(id);
            addSuccessMessage(redirectAttributes, "User deleted successfully.");
        } catch (IllegalArgumentException exception) {
            addErrorMessage(redirectAttributes, exception.getMessage());
        }
        return "redirect:/admin/users";
    }

    @GetMapping("/documents")
    public String documentMonitoring(@RequestParam(required = false) String type,
                                     @RequestParam(required = false) String userEmail,
                                     @RequestParam(defaultValue = "0") int page,
                                     Model model) {
        Page<Document> documents = adminService.getDocuments(type, userEmail, PageRequest.of(Math.max(page, 0), ADMIN_PAGE_SIZE));
        model.addAttribute("documentsPage", documents);
        model.addAttribute("documents", documents.getContent());
        model.addAttribute("type", type);
        model.addAttribute("userEmail", userEmail);
        model.addAttribute("currentPage", documents.getNumber());
        model.addAttribute("totalPages", documents.getTotalPages());
        model.addAttribute("pageSize", ADMIN_PAGE_SIZE);
        return "admin/document-monitoring";
    }

    @PostMapping("/documents/{id}/delete")
    public String deleteDocument(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            adminService.deleteDocument(id);
            addSuccessMessage(redirectAttributes, "Document deleted successfully.");
        } catch (IllegalArgumentException exception) {
            addErrorMessage(redirectAttributes, exception.getMessage());
        }
        return "redirect:/admin/documents";
    }

    @GetMapping("/audit-logs")
    public String auditLogs(@RequestParam(defaultValue = "0") int page, Model model) {
        Page<AuditLog> logs = adminService.getAuditLogs(PageRequest.of(Math.max(page, 0), ADMIN_PAGE_SIZE));
        LinkedHashMap<String, List<AuditLog>> logsByEmail = new LinkedHashMap<>();
        logs.getContent().forEach(log -> {
            String email = log.getUser() != null ? log.getUser().getEmail() : "N/A";
            logsByEmail.computeIfAbsent(email, key -> new java.util.ArrayList<>()).add(log);
        });
        model.addAttribute("logsPage", logs);
        model.addAttribute("logs", logs.getContent());
        model.addAttribute("auditLogGroups", logsByEmail);
        model.addAttribute("currentPage", logs.getNumber());
        model.addAttribute("totalPages", logs.getTotalPages());
        model.addAttribute("pageSize", ADMIN_PAGE_SIZE);
        return "admin/audit-logs";
    }

    @GetMapping("/storage")
    public String storageUsage(Model model) {
        model.addAttribute("reports", adminService.getStorageReports());
        model.addAttribute("storageUsed", adminService.getStorageUsed());
        return "admin/storage-usage";
    }

    @GetMapping("/security-alerts")
    public String securityAlerts(Model model) {
        model.addAttribute("securityAlerts", adminService.getSecurityAlerts());
        return "admin/security-alerts";
    }

    private static String formatStorage(long bytes) {
        double mb = bytes / 1024d / 1024d;
        if (mb < 1d) {
            return String.format(Locale.US, "%.0f KB", bytes / 1024d);
        }
        return String.format(Locale.US, "%.1f MB", mb);
    }

    private static long percentage(long part, long total) {
        if (total <= 0L) {
            return 0L;
        }
        return Math.min(100L, Math.round((part * 100.0d) / total));
    }

    private static void addSuccessMessage(RedirectAttributes redirectAttributes, String message) {
        redirectAttributes.addFlashAttribute(FLASH_SUCCESS_MESSAGE, message);
    }

    private static void addErrorMessage(RedirectAttributes redirectAttributes, String message) {
        redirectAttributes.addFlashAttribute(FLASH_ERROR_MESSAGE, message);
    }
}
