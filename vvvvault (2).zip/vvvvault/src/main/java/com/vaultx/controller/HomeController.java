package com.vaultx.controller;

import com.vaultx.entity.Document;
import com.vaultx.entity.SharedDocument;
import com.vaultx.entity.User;
import com.vaultx.security.CustomUserDetails;
import com.vaultx.service.DocumentService;
import com.vaultx.service.UserService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequiredArgsConstructor
public class HomeController {

    private static final int RECENT_DOCUMENT_LIMIT = 10;
    private static final int SHARES_PAGE_SIZE = 5;

    private final UserService userService;
    private final DocumentService documentService;

    private boolean isAdmin(User user) {
        return user != null && com.vaultx.enums.Role.ROLE_ADMIN.equals(user.getRole());
    }

    @GetMapping("/")
    public String home(@AuthenticationPrincipal CustomUserDetails principal,
                       @RequestParam(defaultValue = "0") int sharesPage,
                       Model model) {
        if (principal == null) {
            return "redirect:/login";
        }
        User user = userService.getById(principal.getId());
        if (isAdmin(user)) {
            return "redirect:/admin/dashboard";
        }
        List<Document> allDocuments = documentService.getMyDocuments(user, "dateDesc", "ALL");
        List<SharedDocument> allSharedDocuments = documentService.getSharedWithMe(user);
        Page<SharedDocument> sharedDocumentsPage = paginateSharedDocuments(allSharedDocuments, sharesPage);
        model.addAttribute("user", user);
        model.addAttribute("totalDocuments", allDocuments.size());
        model.addAttribute("documents", allDocuments.stream().limit(RECENT_DOCUMENT_LIMIT).toList());
        model.addAttribute("totalSharedDocuments", allSharedDocuments.size());
        model.addAttribute("sharedDocumentsPage", sharedDocumentsPage);
        model.addAttribute("sharedDocuments", sharedDocumentsPage.getContent());
        model.addAttribute("currentSharesPage", sharedDocumentsPage.getNumber());
        model.addAttribute("totalSharesPages", sharedDocumentsPage.getTotalPages());
        model.addAttribute("sharesPageSize", SHARES_PAGE_SIZE);
        return "document/dashboard";
    }

    private Page<SharedDocument> paginateSharedDocuments(List<SharedDocument> sharedDocuments, int page) {
        int safePage = Math.max(page, 0);
        int totalShares = sharedDocuments.size();
        int totalPages = totalShares == 0 ? 0 : (int) Math.ceil(totalShares / (double) SHARES_PAGE_SIZE);
        int currentPage = totalPages == 0 ? 0 : Math.min(safePage, totalPages - 1);
        int fromIndex = Math.min(currentPage * SHARES_PAGE_SIZE, totalShares);
        int toIndex = Math.min(fromIndex + SHARES_PAGE_SIZE, totalShares);
        return new PageImpl<>(
                sharedDocuments.subList(fromIndex, toIndex),
                PageRequest.of(currentPage, SHARES_PAGE_SIZE),
                totalShares
        );
    }
}
