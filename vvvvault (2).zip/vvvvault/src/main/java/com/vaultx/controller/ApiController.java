package com.vaultx.controller;

import com.vaultx.entity.User;
import com.vaultx.security.CustomUserDetails;
import com.vaultx.service.DocumentService;
import com.vaultx.service.UserService;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/documents")
@RequiredArgsConstructor
public class ApiController {

    private final DocumentService documentService;
    private final UserService userService;

    @GetMapping("/search")
    public Map<String, Object> search(@AuthenticationPrincipal CustomUserDetails principal,
                                      @RequestParam String keyword) {
        User user = userService.getById(principal.getId());
        return Map.of("keyword", keyword, "results", documentService.searchDocuments(user, keyword));
    }
}
