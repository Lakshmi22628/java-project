package com.vaultx.util;

import jakarta.annotation.PostConstruct;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AesEncryptionUtil {

    private static final String ALGORITHM = "AES/GCM/NoPadding";
    private static final int TAG_LENGTH = 128;
    private static final int IV_LENGTH = 12;

    @Value("${vaultx.security.aes-secret}")
    private String secret;

    private SecretKey secretKey;

    @PostConstruct
    void init() throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] key = digest.digest(secret.getBytes(StandardCharsets.UTF_8));
        secretKey = new SecretKeySpec(Arrays.copyOf(key, 32), "AES");
    }

    public EncryptionResult encrypt(byte[] data) {
        try {
            byte[] iv = new byte[IV_LENGTH];
            new SecureRandom().nextBytes(iv);
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, new GCMParameterSpec(TAG_LENGTH, iv));
            return new EncryptionResult(cipher.doFinal(data), iv);
        } catch (Exception exception) {
            throw new IllegalStateException("Failed to encrypt document", exception);
        }
    }

    public byte[] decrypt(byte[] encryptedData, byte[] iv) {
        try {
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, secretKey, new GCMParameterSpec(TAG_LENGTH, iv));
            return cipher.doFinal(encryptedData);
        } catch (Exception exception) {
            throw new IllegalStateException("Failed to decrypt document", exception);
        }
    }

    @Getter
    @AllArgsConstructor
    public static class EncryptionResult {
        private byte[] encryptedData;
        private byte[] iv;
    }
}
