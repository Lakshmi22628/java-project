package com.vaultx.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import org.apache.poi.xwpf.usermodel.IBodyElement;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.usermodel.BreakType;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.springframework.stereotype.Component;

@Component
public class WordProcessingUtil {

    private final PdfTextExtractor pdfTextExtractor;
    private final PdfProcessingUtil pdfProcessingUtil;

    public WordProcessingUtil(PdfTextExtractor pdfTextExtractor, PdfProcessingUtil pdfProcessingUtil) {
        this.pdfTextExtractor = pdfTextExtractor;
        this.pdfProcessingUtil = pdfProcessingUtil;
    }

    public byte[] docxToPdf(byte[] docxBytes, String sourceName) {
        String extractedText = extractDocxFormattedText(docxBytes);
        if (extractedText.isBlank()) {
            throw new IllegalArgumentException("No extractable text was found in this DOCX document.");
        }
        return pdfProcessingUtil.textToPdf(extractedText, sourceName);
    }

    public byte[] docToPdf(byte[] docBytes, String sourceName) {
        String extractedText = extractDocFormattedText(docBytes);
        if (extractedText.isBlank()) {
            throw new IllegalArgumentException("No extractable text was found in this DOC document.");
        }
        return pdfProcessingUtil.textToPdf(extractedText, sourceName);
    }

    public byte[] pdfToDocx(byte[] pdfBytes, String sourceName) {
        String extractedText = pdfTextExtractor.extractText(pdfBytes, "application/pdf", sourceName);
        if (extractedText == null || extractedText.isBlank()) {
            throw new IllegalArgumentException("No extractable text was found in this PDF.");
        }
        return textToDocx(extractedText);
    }

    public byte[] textToDocx(String text) {
        String safeText = text == null ? "" : text.replace("\r", "");
        try (XWPFDocument document = new XWPFDocument();
             ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            String[] pages = safeText.split("\\f", -1);
            for (int pageIndex = 0; pageIndex < pages.length; pageIndex++) {
                appendPageText(document, pages[pageIndex]);
                if (pageIndex < pages.length - 1) {
                    XWPFParagraph breakParagraph = document.createParagraph();
                    XWPFRun breakRun = breakParagraph.createRun();
                    breakRun.addBreak(BreakType.PAGE);
                }
            }
            document.write(outputStream);
            return outputStream.toByteArray();
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to convert text to DOCX", exception);
        }
    }

    private String extractDocxFormattedText(byte[] docxBytes) {
        try (OPCPackage packageHandle = OPCPackage.open(new ByteArrayInputStream(docxBytes));
             XWPFDocument document = new XWPFDocument(packageHandle)) {
            StringBuilder builder = new StringBuilder();
            for (IBodyElement element : document.getBodyElements()) {
                if (element instanceof XWPFParagraph paragraph) {
                    appendParagraph(builder, paragraph.getText());
                } else if (element instanceof XWPFTable table) {
                    appendTable(builder, table);
                }
            }
            return builder.toString().trim();
        } catch (Exception exception) {
            throw new IllegalStateException("Unable to read DOCX document", exception);
        }
    }

    private String extractDocFormattedText(byte[] docBytes) {
        try (HWPFDocument document = new HWPFDocument(new ByteArrayInputStream(docBytes));
             WordExtractor extractor = new WordExtractor(document)) {
            StringBuilder builder = new StringBuilder();
            for (String paragraph : extractor.getParagraphText()) {
                appendParagraph(builder, cleanWordParagraph(paragraph));
            }
            return builder.toString().trim();
        } catch (Exception exception) {
            throw new IllegalStateException("Unable to read DOC document", exception);
        }
    }

    private void appendPageText(XWPFDocument document, String pageText) {
        String safePageText = pageText == null ? "" : pageText.trim();
        String[] lines = safePageText.split("\\R", -1);
        for (String line : lines) {
            String safeLine = line == null ? "" : line;
            XWPFParagraph paragraph = document.createParagraph();
            if (!safeLine.isBlank()) {
                XWPFRun run = paragraph.createRun();
                run.setText(safeLine);
            }
        }
    }

    private void appendParagraph(StringBuilder builder, String paragraphText) {
        String safeParagraph = paragraphText == null ? "" : paragraphText.trim();
        if (safeParagraph.isBlank()) {
            builder.append('\n');
            return;
        }
        builder.append(safeParagraph).append("\n\n");
    }

    private void appendTable(StringBuilder builder, XWPFTable table) {
        for (XWPFTableRow row : table.getRows()) {
            boolean firstCell = true;
            for (XWPFTableCell cell : row.getTableCells()) {
                if (!firstCell) {
                    builder.append('\t');
                }
                builder.append(cell.getText() == null ? "" : cell.getText().trim());
                firstCell = false;
            }
            builder.append("\n");
        }
        builder.append('\n');
    }

    private String cleanWordParagraph(String paragraph) {
        if (paragraph == null) {
            return "";
        }
        return paragraph.replace("\u0007", "").replace("\r", "").trim();
    }
}
