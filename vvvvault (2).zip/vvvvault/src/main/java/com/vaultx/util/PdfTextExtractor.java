package com.vaultx.util;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.stereotype.Component;

@Component
public class PdfTextExtractor {

    public String extractText(byte[] fileBytes, String contentType, String fileName) {
        String safeFileName = fileName == null ? "" : fileName.toLowerCase();
        String safeContentType = contentType == null ? "" : contentType.toLowerCase();
        boolean isPdf = "application/pdf".equalsIgnoreCase(contentType) || safeFileName.endsWith(".pdf");
        if (isPdf) {
            try (PDDocument document = Loader.loadPDF(fileBytes)) {
                PDFTextStripper stripper = new PDFTextStripper();
                stripper.setSortByPosition(true);
                stripper.setLineSeparator("\n");
                stripper.setWordSeparator(" ");
                stripper.setParagraphStart("");
                stripper.setParagraphEnd("\n");
                stripper.setPageEnd("\f");
                stripper.setSuppressDuplicateOverlappingText(true);
                stripper.setSpacingTolerance(0.5f);
                stripper.setAverageCharTolerance(0.3f);
                return normalizeExtractedText(stripper.getText(document));
            } catch (Exception exception) {
                return "";
            }
        }
        boolean isDocx = "application/vnd.openxmlformats-officedocument.wordprocessingml.document".equalsIgnoreCase(contentType)
                || safeFileName.endsWith(".docx");
        if (isDocx) {
            try (OPCPackage packageHandle = OPCPackage.open(new ByteArrayInputStream(fileBytes));
                 XWPFDocument document = new XWPFDocument(packageHandle);
                 XWPFWordExtractor extractor = new XWPFWordExtractor(document)) {
                return extractor.getText();
            } catch (Exception exception) {
                return "";
            }
        }
        boolean isText = safeContentType.startsWith("text/")
                || safeFileName.endsWith(".txt")
                || safeFileName.endsWith(".md")
                || safeFileName.endsWith(".csv")
                || safeFileName.endsWith(".log");
        if (isText) {
            return normalizeExtractedText(new String(fileBytes, StandardCharsets.UTF_8));
        }
        return "";
    }

    private String normalizeExtractedText(String text) {
        if (text == null || text.isBlank()) {
            return "";
        }
        String normalized = text.replace("\r", "");
        normalized = normalized.replaceAll("[\\t ]+\\n", "\n");
        normalized = normalized.replaceAll("\\n{3,}", "\n\n");
        return normalized.trim();
    }
}
