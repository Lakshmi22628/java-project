package com.vaultx.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.io.IOUtils;
import org.apache.pdfbox.io.RandomAccessReadBuffer;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.multipdf.Splitter;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.springframework.stereotype.Component;

@Component
public class PdfProcessingUtil {

    public byte[] mergePdfDocuments(List<byte[]> pdfDocuments) {
        try {
            PDFMergerUtility merger = new PDFMergerUtility();
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            merger.setDestinationStream(outputStream);
            for (byte[] pdfDocument : pdfDocuments) {
                merger.addSource(new RandomAccessReadBuffer(pdfDocument));
            }
            merger.mergeDocuments(IOUtils.createMemoryOnlyStreamCache());
            return outputStream.toByteArray();
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to merge PDF documents", exception);
        }
    }

    public byte[] imageToPdf(byte[] imageBytes, String imageName) {
        try (PDDocument document = new PDDocument();
             ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            PDImageXObject image = PDImageXObject.createFromByteArray(document, imageBytes, imageName);
            PDPage page = new PDPage(new PDRectangle(image.getWidth(), image.getHeight()));
            document.addPage(page);
            try (var contentStream = new org.apache.pdfbox.pdmodel.PDPageContentStream(document, page)) {
                contentStream.drawImage(image, 0, 0, image.getWidth(), image.getHeight());
            }
            document.save(outputStream);
            return outputStream.toByteArray();
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to convert image to PDF", exception);
        }
    }

    public List<byte[]> splitPdfDocuments(byte[] pdfBytes) {
        try (PDDocument document = Loader.loadPDF(pdfBytes)) {
            List<byte[]> pages = new ArrayList<>();
            Splitter splitter = new Splitter();
            splitter.setSplitAtPage(1);
            for (PDDocument singlePageDocument : splitter.split(document)) {
                try (PDDocument pageDocument = singlePageDocument;
                     ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
                    pageDocument.save(outputStream);
                    pages.add(outputStream.toByteArray());
                }
            }
            return pages;
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to split PDF documents", exception);
        }
    }

    public int getPdfPageCount(byte[] pdfBytes) {
        try (PDDocument document = Loader.loadPDF(pdfBytes)) {
            return document.getNumberOfPages();
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to read PDF page count", exception);
        }
    }

    public byte[] extractPdfPageRange(byte[] pdfBytes, int startPage, int endPage) {
        if (startPage < 1 || endPage < startPage) {
            throw new IllegalArgumentException("Page range must start at 1 and the end page must be after the start page.");
        }
        try (PDDocument document = Loader.loadPDF(pdfBytes);
             PDDocument outputDocument = new PDDocument();
             ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            int totalPages = document.getNumberOfPages();
            if (endPage > totalPages) {
                throw new IllegalArgumentException("The selected range exceeds the number of pages in this PDF.");
            }
            for (int pageNumber = startPage; pageNumber <= endPage; pageNumber++) {
                PDPage page = document.getPage(pageNumber - 1);
                outputDocument.importPage(page);
            }
            outputDocument.save(outputStream);
            return outputStream.toByteArray();
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to extract the selected PDF page range", exception);
        }
    }

    public byte[] extractSpecificPdfPages(byte[] pdfBytes, List<Integer> pageNumbers) {
        if (pageNumbers == null || pageNumbers.isEmpty()) {
            throw new IllegalArgumentException("Select at least one page to extract.");
        }
        try (PDDocument document = Loader.loadPDF(pdfBytes);
             PDDocument outputDocument = new PDDocument();
             ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            int totalPages = document.getNumberOfPages();
            for (Integer pageNumber : pageNumbers) {
                if (pageNumber == null || pageNumber < 1 || pageNumber > totalPages) {
                    throw new IllegalArgumentException("One or more selected pages are outside the page count of this PDF.");
                }
                PDPage page = document.getPage(pageNumber - 1);
                outputDocument.importPage(page);
            }
            outputDocument.save(outputStream);
            return outputStream.toByteArray();
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to extract the selected PDF pages", exception);
        }
    }

    public byte[] textToPdf(String text, String sourceName) {
        String safeText = text == null ? "" : text;
        try (PDDocument document = new PDDocument();
             ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            PDFont font = loadUnicodeFont(document);
            String normalizedText = normalizeForPdf(safeText, font);
            float fontSize = 12f;
            float margin = 50f;
            float leading = fontSize * 1.5f;
            float pageWidth = PDRectangle.A4.getWidth();
            float pageHeight = PDRectangle.A4.getHeight();
            float textWidthLimit = pageWidth - (margin * 2);

            PdfTextWriter writer = new PdfTextWriter(document, font, fontSize, margin, leading, pageHeight);
            for (String paragraph : normalizedText.split("\\r?\\n", -1)) {
                List<String> lines = wrapLines(paragraph, font, fontSize, textWidthLimit);
                if (lines.isEmpty()) {
                    writer.blankLine();
                    continue;
                }
                for (String line : lines) {
                    writer.writeLine(sanitizeForPdf(line));
                }
                writer.blankLine();
            }

            writer.close();
            document.save(outputStream);
            return outputStream.toByteArray();
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to convert text to PDF", exception);
        }
    }

    public boolean isPdf(byte[] bytes) {
        try (PDDocument ignored = Loader.loadPDF(bytes)) {
            return true;
        } catch (IOException exception) {
            return false;
        }
    }

    private List<String> wrapLines(String text, PDFont font, float fontSize, float maxWidth) throws IOException {
        List<String> lines = new ArrayList<>();
        if (text == null || text.isBlank()) {
            return lines;
        }
        String[] words = text.split("\\s+");
        StringBuilder line = new StringBuilder();
        for (String word : words) {
            String candidate = line.isEmpty() ? word : line + " " + word;
            if (font.getStringWidth(candidate) / 1000 * fontSize <= maxWidth) {
                line.setLength(0);
                line.append(candidate);
            } else {
                lines.add(line.toString());
                line.setLength(0);
                line.append(word);
            }
        }
        if (!line.isEmpty()) {
            lines.add(line.toString());
        }
        return lines;
    }

    private String sanitizeForPdf(String text) {
        return text == null ? "" : text.replace("\t", "    ");
    }

    private String normalizeForPdf(String text, PDFont font) throws IOException {
        StringBuilder normalized = new StringBuilder(text.length());
        for (int index = 0; index < text.length(); index++) {
            char character = text.charAt(index);
            if (character == '\r') {
                continue;
            }
            if (character == '\n') {
                normalized.append(character);
                continue;
            }
            if (character == '\t') {
                normalized.append("    ");
                continue;
            }
            String replacement = mapUnsupportedCharacter(character);
            String candidate = replacement == null ? String.valueOf(character) : replacement;
            try {
                font.encode(candidate);
                normalized.append(candidate);
            } catch (IOException exception) {
                normalized.append('?');
            }
        }
        return normalized.toString();
    }

    private String mapUnsupportedCharacter(char character) {
        return switch (character) {
            case '\u2212', '\u2010', '\u2011', '\u2012', '\u2013', '\u2014' -> "-";
            case '\u2018', '\u2019', '\u201A', '\u201B' -> "'";
            case '\u201C', '\u201D', '\u201E' -> "\"";
            case '\u2026' -> "...";
            case '\u2022' -> "*";
            default -> null;
        };
    }

    private PDFont loadUnicodeFont(PDDocument document) {
        String[] candidates = {
                "C:\\Windows\\Fonts\\arial.ttf",
                "C:\\Windows\\Fonts\\calibri.ttf",
                "C:\\Windows\\Fonts\\segoeui.ttf"
        };
        for (String candidate : candidates) {
            File fontFile = new File(candidate);
            if (fontFile.exists() && fontFile.isFile()) {
                try {
                    return PDType0Font.load(document, fontFile);
                } catch (IOException ignored) {
                    // Try the next candidate.
                }
            }
        }
        throw new IllegalStateException("Unable to load a Unicode-capable font for PDF export.");
    }

    private static final class PdfTextWriter {
        private final PDDocument document;
        private final PDFont font;
        private final float fontSize;
        private final float margin;
        private final float leading;
        private final float pageHeight;
        private PDPageContentStream contentStream;
        private float cursorY;

        private PdfTextWriter(PDDocument document, PDFont font, float fontSize, float margin, float leading, float pageHeight) throws IOException {
            this.document = document;
            this.font = font;
            this.fontSize = fontSize;
            this.margin = margin;
            this.leading = leading;
            this.pageHeight = pageHeight;
            startPage();
        }

        private void writeLine(String line) throws IOException {
            ensurePageSpace();
            contentStream.showText(line == null ? "" : line);
            contentStream.newLine();
            cursorY -= leading;
        }

        private void blankLine() throws IOException {
            ensurePageSpace();
            contentStream.newLine();
            cursorY -= leading;
        }

        private void ensurePageSpace() throws IOException {
            if (cursorY > margin + leading) {
                return;
            }
            startPage();
        }

        private void startPage() throws IOException {
            if (contentStream != null) {
                contentStream.endText();
                contentStream.close();
            }
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);
            contentStream = new PDPageContentStream(document, page);
            contentStream.beginText();
            contentStream.setFont(font, fontSize);
            contentStream.setLeading(leading);
            contentStream.newLineAtOffset(margin, pageHeight - margin);
            cursorY = pageHeight - margin;
        }

        private void close() throws IOException {
            if (contentStream != null) {
                contentStream.endText();
                contentStream.close();
            }
        }
    }
}
