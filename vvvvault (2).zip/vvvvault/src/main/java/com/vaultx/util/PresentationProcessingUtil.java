package com.vaultx.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import org.apache.poi.hslf.usermodel.HSLFSlideShow;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.sl.usermodel.TextShape;
import org.apache.poi.hslf.usermodel.HSLFSlide;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.springframework.stereotype.Component;

@Component
public class PresentationProcessingUtil {

    private final PdfProcessingUtil pdfProcessingUtil;

    public PresentationProcessingUtil(PdfProcessingUtil pdfProcessingUtil) {
        this.pdfProcessingUtil = pdfProcessingUtil;
    }

    public byte[] pptToPdf(byte[] presentationBytes, String sourceName, String contentType) {
        String extractedText = extractPresentationText(presentationBytes, sourceName, contentType);
        if (extractedText.isBlank()) {
            throw new IllegalArgumentException("No extractable text was found in this PowerPoint presentation.");
        }
        return pdfProcessingUtil.textToPdf(extractedText, sourceName);
    }

    private String extractPresentationText(byte[] presentationBytes, String sourceName, String contentType) {
        String normalizedContentType = contentType == null ? "" : contentType.toLowerCase();
        String normalizedName = sourceName == null ? "" : sourceName.toLowerCase();
        boolean isPptx = normalizedContentType.equals("application/vnd.openxmlformats-officedocument.presentationml.presentation")
                || normalizedName.endsWith(".pptx");

        try {
            if (isPptx) {
                try (OPCPackage packageHandle = OPCPackage.open(new ByteArrayInputStream(presentationBytes));
                     XMLSlideShow slideshow = new XMLSlideShow(packageHandle)) {
                    return extractTextFromXslfSlides(slideshow.getSlides());
                }
            }
            try (HSLFSlideShow slideshow = new HSLFSlideShow(new ByteArrayInputStream(presentationBytes))) {
                return extractTextFromHslfSlides(slideshow.getSlides());
            }
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to read PowerPoint presentation", exception);
        } catch (Exception exception) {
            throw new IllegalStateException("Unable to read PowerPoint presentation", exception);
        }
    }

    private String extractTextFromXslfSlides(List<XSLFSlide> slides) {
        StringBuilder text = new StringBuilder();
        for (int index = 0; index < slides.size(); index++) {
            appendSlideText(text, "Slide " + (index + 1), slides.get(index).getShapes());
        }
        return text.toString().trim();
    }

    private String extractTextFromHslfSlides(List<HSLFSlide> slides) {
        StringBuilder text = new StringBuilder();
        for (int index = 0; index < slides.size(); index++) {
            appendSlideText(text, "Slide " + (index + 1), slides.get(index).getShapes());
        }
        return text.toString().trim();
    }

    private void appendSlideText(StringBuilder target, String slideLabel, List<?> shapes) {
        if (target.length() > 0) {
            target.append("\n\n");
        }
        target.append(slideLabel);
        for (Object shape : shapes) {
            if (shape instanceof TextShape<?, ?> textShape) {
                String shapeText = textShape.getText();
                if (shapeText != null && !shapeText.isBlank()) {
                    target.append("\n").append(shapeText.trim());
                }
            }
        }
    }
}
