document.addEventListener("DOMContentLoaded", () => {
    const toggleButton = document.querySelector("[data-doc-toggle='main-tools']");
    const sections = Array.from(document.querySelectorAll("[data-doc-section='main-tools']"));

    if (toggleButton && sections.length) {
        toggleButton.addEventListener("click", () => {
            window.location.href = "/documents/tools";
        });
    }

    document.querySelectorAll("a.vaultx-sidebar-link[href^='#']").forEach((link) => {
        link.addEventListener("click", (event) => {
            const targetId = link.getAttribute("href").slice(1);
            const pageRoutes = {
                upload: "/documents/upload-page",
                search: "/documents/search-page",
                arrange: "/documents/sort-page",
                tools: "/documents/tools",
            };
            if (pageRoutes[targetId]) {
                event.preventDefault();
                window.location.href = pageRoutes[targetId];
                return;
            }
        });
    });

    document.querySelectorAll("[data-category-select]").forEach((select) => {
        const form = select.closest("form");
        const wrap = form ? form.querySelector("[data-custom-category-wrap]") : null;
        const customInput = wrap ? wrap.querySelector("input") : null;
        if (!wrap || !customInput) {
            return;
        }

        const syncVisibility = () => {
            const showCustom = select.value === "OTHER" || customInput.value.trim().length > 0;
            wrap.style.display = showCustom ? "block" : "none";
        };

        select.addEventListener("change", syncVisibility);
        syncVisibility();
    });
});
