document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll(".vaultx-password-field").forEach((field) => {
        const input = field.querySelector("input");
        const button = field.querySelector(".vaultx-password-toggle");
        if (!input || !button) {
            return;
        }
        button.addEventListener("click", () => {
            const showPassword = input.type === "password";
            input.type = showPassword ? "text" : "password";
            button.textContent = showPassword ? "Hide" : "Show";
            button.setAttribute("aria-label", showPassword ? "Hide password" : "Show password");
        });
    });
});
