(function () {
    const form = document.getElementById('profile-picture-form');
    const input = document.querySelector('input[name="profilePicture"]');
    const csrfTokenMeta = document.querySelector('meta[name="_csrf"]');
    const csrfHeaderMeta = document.querySelector('meta[name="_csrf_header"]');
    const csrfToken = csrfTokenMeta ? csrfTokenMeta.getAttribute('content') : '';
    const csrfHeader = csrfHeaderMeta ? csrfHeaderMeta.getAttribute('content') : 'X-CSRF-TOKEN';

    if (!form || !input) {
        return;
    }

    form.addEventListener('submit', function (event) {
        if (!input.files || input.files.length === 0) {
            event.preventDefault();
            alert('Please choose an image before saving.');
            return;
        }

        event.preventDefault();

        const formData = new FormData(form);
        fetch('/profile/picture', {
            method: 'POST',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                [csrfHeader]: csrfToken
            },
            body: formData
        })
            .then(function (response) {
                return response.text().then(function (text) {
                    let data = {};
                    if (text) {
                        try {
                            data = JSON.parse(text);
                        } catch (error) {
                            data = { message: text };
                        }
                    }
                    if (!response.ok) {
                        throw new Error(data.message || 'Profile picture upload failed.');
                    }
                    return data;
                });
            })
            .then(function () {
                window.location.href = '/profile?picture=success';
            })
            .catch(function (error) {
                alert(error.message || 'Profile picture upload failed.');
            });
    });
})();
