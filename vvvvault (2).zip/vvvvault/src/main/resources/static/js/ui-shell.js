document.addEventListener("DOMContentLoaded", () => {
    const root = document.body;
    const toggleButtons = Array.from(document.querySelectorAll("[data-theme-toggle]"));
    if (!toggleButtons.length) {
        return;
    }

    const storageKey = "vaultx-theme";
    const storedTheme = localStorage.getItem(storageKey);
    const prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
    const initialTheme = storedTheme || (prefersDark ? "dark" : "light");

    const applyTheme = (theme) => {
        root.dataset.theme = theme;
        localStorage.setItem(storageKey, theme);
        toggleButtons.forEach((button) => {
            button.textContent = theme === "dark" ? "Light mode" : "Dark mode";
            button.classList.toggle("btn-outline-dark", theme !== "dark");
            button.classList.toggle("btn-outline-light", theme === "dark");
        });
    };

    applyTheme(initialTheme);

    toggleButtons.forEach((button) => {
        button.addEventListener("click", () => {
            const nextTheme = root.dataset.theme === "dark" ? "light" : "dark";
            applyTheme(nextTheme);
        });
    });
});
