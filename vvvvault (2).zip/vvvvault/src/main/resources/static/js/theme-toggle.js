document.addEventListener("DOMContentLoaded", () => {
    const themeKey = "vaultx-theme";
    const toggles = Array.from(document.querySelectorAll("#themeToggle, [data-theme-toggle]"));
    const setTheme = (theme) => {
        document.body.dataset.theme = theme;
        localStorage.setItem(themeKey, theme);
        toggles.forEach((toggle) => {
            toggle.textContent = theme === "dark" ? "Light Mode" : "Dark Mode";
        });
    };

    const storedTheme = localStorage.getItem(themeKey);
    setTheme(storedTheme === "dark" ? "dark" : "light");

    toggles.forEach((toggle) => {
        toggle.addEventListener("click", () => {
            const nextTheme = document.body.dataset.theme === "dark" ? "light" : "dark";
            setTheme(nextTheme);
        });
    });
});
